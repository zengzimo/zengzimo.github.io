"use strict";

var fs = require("fs");
var gulp = require("gulp");
var runSeq = require("run-sequence");
var requireDir = require('require-dir');
var bs = require("browser-sync").create();

requireDir('./tasks', {recurse: true});

gulp.task("default", ["run.static"]);
// gulp.task("default", ["run.dev"])

/**
 * Apply to real IDE, all files will output to AN's project dir
 * with sourceMap
 * without compress
 */
gulp.task("dev", ["run.dev"]);

/**
 * Apply to real IDE, all files will output to AN's project dir
 * with compress
 * without sourceMap
 */
gulp.task("prod", ["run.prod"]);

/**
 * Apply to simulative IDE, using json data
 * with sourceMap
 * without compress
 */
gulp.task("static", ["run.static"]);

//Run dev mode.
gulp.task("run.dev", function(done) {
  return runSeq("clean.dev", "build.dev", "copy.dev", done);
});

//Run prod mode.
gulp.task("run.prod", function(done) {
  return runSeq("clean.prod", "build.prod", "copy.prod", done);
});

//Run static mode.
gulp.task("run.static", function(done) {
  return runSeq("clean.static", "build.static", "copy.static", "copyJSON", "browserSync", done);
});

gulp.task("copyJSON", function() {
  return gulp.src("json/**/*", {base:"."})
    .pipe(gulp.dest("dist"));
});

gulp.task("browserSync", function() {
  bs.init({
    server: {
      baseDir: "dist",
      middleware: function(req, res, next) {
        let url = req.url;
        let lastIndexOfParam = url.lastIndexOf('?');
        ~lastIndexOfParam && (req.url = url.slice(0, lastIndexOfParam));
        req.url = resetUrl(req.url);
        if (!fs.existsSync("dist/" + req.url)) req.url = "/" + req.url.split("/")[1] + ".html";
        next();
      }
    },
    files: ["dist/**/*"],
    // startPath: "/resources"
    startPath: "/reservation"
  });
});


// make sure request url is corresponse to your html name
var pages = ["resources", "reservation", "permitDetail", "cart"];

function resetUrl(url) {
  return pages.some(function(page) {
    var reg = new RegExp("^\\/"+page);
    if (reg.test(url)) return "/"+page+".html";
  })[0] || url;
}

