# New front-end architecture of ActiveNet AUI
This new architecture is based on the [Arch Reform Base](https://gitlab.dev.activenetwork.com/fee/arch-reform-base) provided by FEE team.

## Framework and library need to know
-----------------------------------------------------------

* **React:** View layer. A componentized design for web pages. [learn react](https://facebook.github.io/react/)

* **Immutable:** State storage library, a perfect companion to React.[learn immutable](https://facebook.github.io/immutable-js/)

* **AFlux:** A loosely coupled message based coordination/communication architecture.Help to handle business logic coordination for you no matter how complex an application is.[learn AFlux](https://gitlab.dev.activenetwork.com/fee/aflux)

* **AAUI:** ACTIVE AUI components library. With this, we can easily reuse existing components described in the AUI style guide. [learn AAUI](http://fee:9005/)

* **ES6**: [the-next-version-of-javascript](http://weblogs.asp.net/dwahlin/getting-started-with-es6-%E2%80%93-the-next-version-of-javascript). And you may need to know the [ES5](http://speakingjs.com/es5/ch25.html) if you have little js knowledge.

## Steps to run the AUI from local
-----------------------------------------------------------

1. node install
2. download the repository
```
git clone https://gitlab.dev.activenetwork.com/ActiveNet/aui.git
```
3. enter the root directory
```
cd aui
```
4. run `npm install` in the command line
5. run `npm install -g gulp` to ensure the gulp avaliable globally
6. run `npm start` in the command line to start the local server. If the the server start successfully you will see the booking page open in your default browser automatically. And any changes to the file can be immediately manifested in the browser. Cool!
