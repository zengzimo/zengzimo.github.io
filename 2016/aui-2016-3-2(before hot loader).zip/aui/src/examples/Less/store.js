"use strict";

import {Store, addStore} from "aflux";
import {fromJS} from "immutable";
import renderRoot from "shared/components/Root";
/* view */
import Resources from "./components/Less";

const store = new Store();
let data = fromJS({});

addStore(store);

store.on("render.less", (dataView) => {
  data = dataView ? dataView : data;
  renderRoot(Resources, data);
});
