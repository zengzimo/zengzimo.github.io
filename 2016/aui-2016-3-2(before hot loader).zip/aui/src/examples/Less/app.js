"use strict";

import "./app.less";
import "./store";

flux.dispatch("render.less");
