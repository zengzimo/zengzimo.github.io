"use strict";

import "./less.less";

import Grid from "../Grid";

export default React.createClass({

  displayName: "Less",

  render() {

    return (
      <div className="less-demo">
        <h1>Grid column</h1>
        <Grid/>
        <h1>Form</h1>
      </div>
    );
  }

});
