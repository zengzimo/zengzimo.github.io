"use strict";

import {Store, addStore} from "aflux";
import {fromJS} from "immutable";
import QAjax from "shared/libs/QAjax";

const store = new Store();

export let data = [];
let ind = 0;


store.on("cart.init", (callback) => {
	QAjax(
		"/json/Cart/cart.json", 
		function(response) {
			data = fromJS(response.result);
			flux.dispatch("render.cart", data);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});


addStore(store);
