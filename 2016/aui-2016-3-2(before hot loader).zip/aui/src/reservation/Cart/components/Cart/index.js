"use strict";

import "./Root.less";
import {fromJS} from "immutable";
import AAUIButton from "react-aaui/Button";
import Hyperlink from "shared/components/Hyperlink";

export default React.createClass({
  displayName: "Root",

  mixins: [PureRenderMixin],

  getInitialState() {
    return {
      dataView: this.props.data
    };
  },

  render() {
    return (
      <section className="cart">
        <div> 
          <h2 className="title">Cart</h2>
        </div>
        <div className="wrapper reservation">
          <div className="box spaceBetween">
            <h3 className="reservationTitle">Reservation</h3>
            <a className="link" href="/resources"><i className="icon plus-icon"></i> New permit</a>
          </div>
          <ul>
            <li className="reservationHeader">
                <div>TRANSACTION DESCRIPTION</div>
                <div>AMOUNT</div>
                <div>ACTION</div>
            </li>
            {
              this.state.dataView.map(function(data, index){
                  return <div key={data.get("desc") + "_" + index}> 
                           <li className="item">
                              <div><a className="link" href="/permitDetail">{data.get("desc")}</a></div>
                              <div>$ {data.get("amount")}</div>
                              <div><a className="link" href="/permitDetail"><i className="icon edit-icon"></i></a> <i className="icon delete-icon"></i></div>
                           </li>
                           <li>
                              <ul className="itemDetail">
                                  {
                                    data.get("children").map(function(item, i){
                                      return <li key={item.get("desc") + "_" + i}>
                                                <div>{item.get("desc")}</div>
                                                <div>${item.get("amount")}</div>
                                                <div></div>
                                            </li>
                                    })
                                  }
                              </ul>
                           </li>
                         </div>
              })
            }
          </ul>
        </div>
        <div className="wrapper totalFee">
          <span>TOTAL $ 370.00</span>
        </div>
        <div className="box spaceBetween marginTop">
          <AAUIButton   onClick={(e) => console.log(e)}>Cancel</AAUIButton>
          <div className="backBtn"> <AAUIButton  onClick={(e) => console.log(e)}>Back</AAUIButton></div>
          <AAUIButton type="primary" onClick={(e) => console.log(e)}>Check Out</AAUIButton>
        </div>
      </section>
    );
  }
});