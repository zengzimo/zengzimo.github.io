"use strict";

export default React.createClass({
  displayName: "App",
  mixins: [PureRenderMixin],

  render() {
    const Module = this.props.view;
    return (
      <Module data={this.props.data}/>
    );
  },
});
