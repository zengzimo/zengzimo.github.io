"use strict";

import {Store, addStore} from "aflux";
import ReactDOM from "react-dom";
import Root from "./components/Root";
import cart from "./components/Cart";
import * as cartStore from "./store";

const store = new Store();

let view = cart;

function renderApp(data) {
  ReactDOM.render(<Root view={view} data={data}/>, document.getElementById("app-root"));
}

store.on("render.cart", () => {
  renderApp(cartStore.data);
});

addStore(store);

