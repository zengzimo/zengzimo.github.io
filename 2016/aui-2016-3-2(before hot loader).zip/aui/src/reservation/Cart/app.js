"use strict";

import "./app.less";
import "shared/libs/iframe";
import "./root";

flux.dispatch("cart.init");
