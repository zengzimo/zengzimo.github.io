module.exports = {
	"permits": [{ 
		"id": 1,
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Approved"
	}, { 
		"id": 2, 
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Denied"
	}, { 
		"id": 3,
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Tentative"
	}, { 
		"id": 4, 
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Stage Denied"
	}, { 
		"id": 5,
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Issued"
	}, { 
		"id": 6, 
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Cancelled"
	}, { 
		"id": 7,
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Waiting Decision"
	}, { 
		"id": 8, 
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Approved"
	}, { 
		"id": 9,
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "Completed"
	}, { 
		"id": 10, 
		"permit": "6334.541783",
		"eventName": "2015 Annual Party",
		"site": "Vancou...",
		"customer": "John Smith",
		"completedPerson": "Nolan Niu",
		"createdTime": "Dec 13 2014",
		"status": "On Hold"
	}]
}