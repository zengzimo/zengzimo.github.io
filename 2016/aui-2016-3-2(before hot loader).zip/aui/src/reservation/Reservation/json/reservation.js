module.exports = {
	"statuses": [{
		"text": "Approved",
		"value": 0
	}, {
		"text": "Denied",
		"value": 1
	}, {
		"text": "Tentative",
		"value": 2
	}, {
		"text": "Stage Denied",
		"value": 3
	}, {
		"text": "Issued",
		"value": 4
	}, {
		"text": "Cancelled",
		"value": 5
	}, {
		"text": "Waiting Decision",
		"value": 6
	}, {
		"text": "Completed",
		"value": 7
	}, {
		"text": "On Hold",
		"value": 8
	}, {
		"text": "all",
		"value": "all"
	}],
	// "reservations": [{
	// 	"name": "John Smith Annual Party Reservation",
	// 	"price": 200
	// }, {
	// 	"name": "Taylor Live Show Reservation with a even longer longer name longer name",
	// 	"price": 201
	// }, {
	// 	"name": "reservation #3",
	// 	"price": 202
	// }, {
	// 	"name": "John Smith Annual Party Reservation",
	// 	"price": 200
	// }, {
	// 	"name": "Taylor Live Show Reservation with a even longer longer name longer name",
	// 	"price": 201
	// }, {
	// 	"name": "reservation #3",
	// 	"price": 202
	// }, {
	// 	"name": "John Smith Annual Party Reservation",
	// 	"price": 200
	// }, {
	// 	"name": "Taylor Live Show Reservation with a even longer longer name longer name",
	// 	"price": 201
	// }, {
	// 	"name": "reservation #3",
	// 	"price": 202
	// }, {
	// 	"name": "John Smith Annual Party Reservation",
	// 	"price": 200
	// }, {
	// 	"name": "Taylor Live Show Reservation with a even longer longer name longer name",
	// 	"price": 201
	// }, {
	// 	"name": "reservation #3",
	// 	"price": 202
	// }],

	// "reservations": [{
	// 	"name": "John Smith Annual Party Reservation",
	// 	"price": 200
	// }, {
	// 	"name": "Taylor Live Show Reservation with a even longer longer name longer name",
	// 	"price": 201
	// }],


	reservations: [],
	"total": 603
}