"use strict";

import {Store, addStore} from "aflux";
import {fromJS} from "immutable";
import renderRoot from "shared/components/Root";
import Reservation from "./components/Reservation";
import QAjax from "shared/libs/QAjax";
import URL from "shared/libs/url" ;
import Data from "./json/reservation";

const store = new Store();

let permitsOptions = {
	url: URL.permits,
	method: "POST",
	data: {
		online : false,
		use_search_pattern : false, 
		startpermit : 0,
		endpermit : 10,
		site_id : 0,
		center_id : 0, //center id
		use_sort : true,
		sort_by_field : 'permitnumber', // eventname, sitename, firstname, lastname, permitnumber, username
		sort_asc : true,
		paging : true,   // true or false
		page_number : 2,
		per_page_size : 10
	}
};

let statusFlag = "";

let data = fromJS(Object.assign(Data, {
	centers: [],
	permits: [],
	sites: [],
	pagination: {
		totalPages: 0,
        currentPage: 1
	}
}));

addStore(store);
store.on("goto.reservation", () => {
	flux.dispatch("sites.list");
	flux.dispatch("centers.list");
	flux.dispatch("permits.default");
	// flux.dispatch("status.list");
	flux.dispatch("render.reservation");
});

store.on("render.reservation", () => {
  	renderRoot(Reservation, data);
});

store.on("sites.list", () => {
	QAjax(
		URL.sites,
		function(response) {
			let sites = response;
			sites = sites.map((siteObj) => {
				return Object.assign(siteObj, {
					text: siteObj.name,
					value: siteObj.id
				})
			})
			data = data.set("sites", fromJS(sites));
			data = data.set("defaultSite", sites[0].id);
			flux.dispatch("render.reservation", data);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});

store.on("centers.list", () => {
	QAjax(
		URL.centers,
		function(response) {
			let centers = response;
			centers = centers.map((centerObj) => {
				return Object.assign(centerObj, {
					text: centerObj.name,
					value: centerObj.id
				})
			})
			data = data.set("centers", fromJS(centers))
			data = data.set("defaultCenter", centers[0].id);
			flux.dispatch("render.reservation", data);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});

//-- todo
store.on("status.list", () => {
	QAjax(
		URL.status,
		function(response) {
			console.log(response)
			// let sites = response;
			// sites = sites.map((siteObj) => {
			// 	return Object.assign(siteObj, {
			// 		text: siteObj.name,
			// 		value: siteObj.id
			// 	})
			// })
			// data = data.set("sites", fromJS(sites));
			// data = data.set("defaultSite", sites[0].id);
			// flux.dispatch("render.reservation", data);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});

store.on("permits.default", () => {
	fetchPermits({page_number: data.getIn(["pagination", "currentPage"])});
});

store.on("permits.site", ({value}) => {
	fetchPermits({site_id: value});
});

store.on("permits.center", ({value}) => {
	fetchPermits({center_id: value});
});

store.on("permits.status", ({value}) => {
	let statusParam = {};
	let key = "option" + value
	statusParam[key] = true
	fetchPermits(statusParam);
	statusFlag = key;
});

//-- todo
store.on("permits.startDate", (startDate) => {
	fetchPermits();
});


//-- todo
store.on("permits.endDate", (endDate) => {
	fetchPermits();
});

store.on("permits.permitId", (permitNumber) => {
	fetchPermits({startpermit: permitNumber});
});

store.on("permits.changePage", (curPage) => {
	fetchPermits({page_number: curPage}, () => {
		data = data.setIn(["pagination", "currentPage"], curPage);
	});
});

store.on("permits.sort", (column, key, sortDirection) => {
	let sort_asc = sortDirection === "asc";
	fetchPermits({
		sort_asc: sort_asc,
		sort_by_field: column.get("sort_field")
	}, () => {
		column.set("sort", sortDirection);
	});
});

function fetchPermits(options, callback) {
	let fetchData = permitsOptions.data;
	if (fetchData[statusFlag]) {
		delete fetchData[statusFlag];
	}
	
	options && Object.assign(fetchData, options);

	console.log('fetchData : ')
	console.log(fetchData)
	
	QAjax(
		permitsOptions,
		function(response) {
			if (callback && typeof callback === "function") {
				callback();
			}
			console.log('fetch permits : ')
			console.log(response)
			data = data.setIn(["pagination", "totalPages"], 6); //需要真实的数据
			updatePermits(response);
		}, function(xhr) {
			updatePermits([]);
		}
	);
}

function updatePermits(permits) {
	data = data.set("permits", fromJS(permits));
	flux.dispatch("render.reservation", data);
}