"use strict";

import CartList from "../CartList";
import GridFilter from "../GridFilter";
import Action from "../Action";
import Grid from "../Grid";
import IconButton from "shared/components/IconButton";
import * as da from "react-aaui/shared/data-access";
import URL from "shared/libs/url";

export default React.createClass({
  displayName: "Reservation",
  mixins: [PureRenderMixin],
  render() {
    let statuses = this.props.data.get("statuses");
    return (
      <section className="reservation">
      	<h1>Bookings</h1>
        <div className="entry">
          <IconButton title="View Resource Calendar" iconClassName="calendar-icon" isIconLink={true} link={URL.bookingPage}>
          </IconButton>
          <CartList reservations={this.props.data.get("reservations")} total={this.props.data.get("total")}></CartList>
        </div>
        <GridFilter sites={this.props.data.get("sites")} centers={this.props.data.get("centers")} statuses={statuses} defaultSite={this.props.data.get("defaultSite")} defaultCenter={this.props.data.get("defaultCenter")}></GridFilter>
        <div className="wrapper">
          <Action statuses={statuses}/>
          <Grid data={this.props.data.get("permits")} pagination={this.props.data.get("pagination")}></Grid>
        </div>
      </section>
    );
  }
});
