"use strict";
import "./CartList.less";
import PopList from "shared/components/PopList";

export default React.createClass({

    displayName: "paymentOptions",
    mixins: [PureRenderMixin],

    render() {
        return (<PopList className="cart-list" data={this.props.reservations} total={this.props.total} href="/cart" title="View Cart" iconClassName="cart-icon"/>);
    }
});
