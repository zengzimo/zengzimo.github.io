"use strict";

import "./GridFilter.less";
import Dropdown from "react-aaui/Dropdown";
import DatePicker from "react-aaui/DatePicker";
import Input from "react-aaui/Input";
import IconButton from "shared/components/IconButton";

export default React.createClass({
  displayName: "paymentOptions",
  mixins: [PureRenderMixin],

  render() {
    return (
      <div className="grid-filter wrapper aaui-flexbox">
        <Input className="flexbox-item filter-input" placeholder="Enter permit number" size="m" ref="search" style={{width: 220}}/>
        <div className="flexbox-item">
          <div className="aaui-flexbox">
            <label>
              Site
              <Dropdown data={this.props.sites} placeholder="Site name" onChange={this.changeSite}/>
            </label>
            <label>
              Center
              <Dropdown data={this.props.centers} placeholder="Center name" onChange={this.changeCenter}/>
            </label>
            <label>
              Facility Type
              <Dropdown data={this.props.centers} placeholder="All" onChange={this.changeCenter}/>
            </label>
          </div>
          <div className="aaui-flexbox">
            <label>
              Event Date
              <div className="datepicker-wrapper">
                <DatePicker defaultValue={new Date()} onChange={this.changeStartDate}/>
                <span>--</span>
                <DatePicker defaultValue={new Date()} onChange={this.changeEndDate}/>
              </div>
            </label>
            
            <label>
              Status
              <Dropdown data={this.props.statuses} placeholder="All" onChange={this.changeStatus}/>
            </label>
          </div>
        </div>
        <div className="flexbox-item" onClick={this.permitIdSearch}>
            <IconButton className="searchWrapper" iconClassName="search-icon"></IconButton>
          </div>
      </div>
    );
  },

  changeSite({value}) {
    flux.dispatch("permits.site", {value});
  },

  changeCenter({value}) {
    flux.dispatch("permits.center", {value});
  },

  changeStatus({value}) {
    flux.dispatch("permits.status", {value});
  },

  changeStartDate(val) {
    flux.dispatch("permits.startDate", val);
  },

  changeEndDate(val) {
    flux.dispatch("permits.EndDate", val);
  },

  permitIdSearch() {
    flux.dispatch("permits.permitId", this.refs.search.value);
  }
});
