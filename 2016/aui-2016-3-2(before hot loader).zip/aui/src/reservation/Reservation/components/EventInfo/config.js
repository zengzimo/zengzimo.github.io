"use strict";
import {fromJS} from "immutable";

export default fromJS([{
	name: "name",
	title: "NAME",
	width: "20%"
}, {
	name: "date",
	title: "DATE & TIME",
	width: "50%"
}, {
	name: "qty",
	title: "QTY",
	render: function(cellContent) {
		cellContent = cellContent || "--";
		return cellContent;
	}
}, {
	name: "atnd",
	title: "ATND",
	render: function(cellContent) {
		cellContent = cellContent || "--";
		return cellContent;
	}
}])