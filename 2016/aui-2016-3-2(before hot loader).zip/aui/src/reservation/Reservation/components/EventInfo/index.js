"use strict";

import "./EventInfo.less";
import Modal from "react-aaui/Modal";
import Button from "react-aaui/Button";
import DataGrid from "shared/components/DataGrid";
import Columns from "./config";
import {fromJS} from "immutable";

let data = fromJS([{
	name: "2016 Annual Party",
	people: 200,
	reservations: [{
		name: "Facility Name",
		date: "10/08/2015  9:00AM -- 10/08/2015  10:00AM",
		atnd: 1
	}, {
		name: "Facility Name",
		date: "10/08/2015  9:00AM -- 10/08/2015  10:00AM",
		atnd: 1
	}, {
		name: "Equipment Name",
		date: "10/08/2015  9:00AM -- 10/08/2015  10:00AM",
		qty: 34
	}, {
		name: "Instructor Name",
		date: "10/08/2015  9:00AM -- 10/08/2015  10:00AM"
	}]
}, {
	name: "2016 New Year Party",
	people: 250,
	reservations: [{
		name: "Facility Name",
		date: "10/08/2015  9:00AM -- 10/08/2015  10:00AM",
		atnd: 1
	}, {
		name: "Facility Name",
		date: "10/08/2015  9:00AM -- 10/08/2015  10:00AM",
		atnd: 1
	}]
}])

export default React.createClass({
	displayName: "EventInfo",
	mixins: [PureRenderMixin],

	render() {
		return (
		    <Modal title="Event Information" {...this.props} className="eventInfo">
		    	<div className="aaui-modal-body">
	            	{this.renderEvent()}
	          	</div>
	          	<div className="aaui-modal-footer">
		            <Button type="secondary" onClick={this.props.onClose}>Close</Button>
		            <Button type="secondary" disabled={true} onClick={this.editBooking}>Edit Booking</Button>
	          	</div>
		    </Modal>
		);
	},

	renderEvent() {
		return data.map((eventInfo, key) => {
			return (
				<div key={key} className="event-wrapper">
					<div className="title">
						{eventInfo.get("name")}
						<span className="people">
							<i className="user-icon fa"></i>
							{eventInfo.get("people")}
						</span>
					</div>
					<DataGrid data={eventInfo.get("reservations")} columns={Columns} pagination={false}/>
				</div>
			)
		})
	},

	editBooking() {

	}
});