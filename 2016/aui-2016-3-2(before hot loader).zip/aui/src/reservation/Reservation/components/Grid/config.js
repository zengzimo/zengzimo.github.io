"use strict";

import Checkbox from "react-aaui/Checkbox";
import Popover from "react-aaui/Popover";
import {fromJS} from "immutable";

const statusColorMap = {
	"Approved": "green",
	"Denied": "red",
	"Tentative": "#748288",
	"Stage Denied": "red",
	"Issued": "red",
	"Cancelled": "red",
	"Waiting Decision": "#748288",
	"Completed": "green",
	"On Hold": "yellow"
};


export default fromJS({
	columns: [{
		width: 50,
		renderHeader: function() {
			return <div className="control-cell"><Checkbox size="s" disabled={true} onChange={this.props.onSelect}></Checkbox></div>
		},
		render: function(content, rowIndex) {
			let permitStatus = this.props.data.getIn([rowIndex, "permit_status"]);

			return <div className="aaui-table-cell control-cell" style={{borderLeftColor: statusColorMap[permitStatus]}}><Checkbox size="s" disabled={true} onChange={this.props.onSelect(rowIndex)}></Checkbox></div>
		}
	}, {
		"name": "permit_number",
		"title": "PERMIT #",
		"width": "10%",
		"sort": "asc",
		"sort_field": "permitnumber"
	}, {
		"name": "event_name",
		"title": "EVENT NAME",
		"width": "20%",
		"sort": "asc",
		"sort_field": "eventname",
		"cellClassName": "cursor",
		// "render": function(cellContent) {
		// 	return <div className="aaui-table-cell" onClick={this.props.showEventInfo}>{cellContent}</div>
		// }
		"render": function(cellContent) {
			return <div className="aaui-table-cell">{cellContent}<div className="pop-base"><Popover className="pop" direction="bottom" arrow="middle"><div>2 events(10 booking items)</div><div>Owner: John Smith</div><div>From: 25 Jan 2016</div><div>To: 30 Jan 2016</div><div>Status: Approved</div></Popover></div></div>
		}
	}, {
		"name": "site_name",
		"title": "SITE",
		"sort_field": "sitename"
	}, {
		"name": "customer_name",
		"title": "CUSTOMER",
		"width": "15%"
	}, {
		"name": "permit_date",
		"title": "START DATE",
		"width": "15%"
	}/*, {
		"name": "permit_status",
		"title": "STATUS",
		"width": "5%"
	}*/]
})