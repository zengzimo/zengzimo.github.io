"use strict";

import "./Grid.less";
import DataGrid from "shared/components/DataGrid";
import EventInfo from "../EventInfo";
import config from "./config";
import {is as Is} from "immutable";

let columns = config.get("columns");

export default React.createClass({
	displayName: "Grid",
	mixins: [PureRenderMixin],

	render() {
		return (
			<div className='permits-list'>
		    	<DataGrid data={this.props.data} columns={this.state.columns} pagination={this.props.pagination.toJS()} onChange={this.onChange} onSort={this.onSort} showEventInfo={this.showEventInfo} onSelect={this.onSelect}/>
		    	<EventInfo shown={this.state.isDisplayed} onClose={this.close}/>
		    </div>
		);
	},

	onChange(curPage) {
		flux.dispatch("permits.changePage", curPage);
	},

	onSort(column, key, sortDirection) {
		columns = this.state.columns.setIn([key, 'sort'], sortDirection);
		flux.dispatch("permits.sort", column, key, sortDirection);
	},

	componentWillReceiveProps(nextProps) {
		if (!Is(columns, this.state.columns)) {
			this.setState({columns: columns});
		}
	},

	getInitialState() {
	    return {
	    	columns: columns,
	    	isDisplayed: false
	    };
	},

	showEventInfo() {
		this.setState({
	      	isDisplayed: true
	    });
	},

	close() {
	    this.setState({
	      	isDisplayed: false
	    });
	},

	onSelect(rowIndex) {
		return function() {
			// console.log(rowIndex)
		}
	}
});