"use strict";

export default [{
	text: "Status 1",
	value: "Status 1"
}, {
	text: "Status 2",
	value: "Status 2"
}, {
	text: "Status 3",
	value: "Status 3"
}, {
	text: "Status 4",
	value: "Status 4"
}, {
	text: "Status 5",
	value: "Status 5"
}, {
	text: "Status 6",
	value: "Status 6"
}]