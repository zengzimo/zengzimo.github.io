"use strict";

import "./Action.less";
import Hyperlink from "shared/components/Hyperlink";
import Button from "react-aaui/Button";
import Dropdown from "react-aaui/Dropdown";
import ActionConfig from "./config";
import URL from "shared/libs/url";

const MaxShowCount = 3;

export default React.createClass({
	displayName: "Action",
	mixins: [PureRenderMixin],

	render() {
		return (
		    <div className="booking-action">
		    	<Hyperlink className="aaui-button aaui-button-secondary aaui-button-size-s link" href={URL.bookingPage}>
		    		<i className="plus-icon icon" onClick={this.toggleCartList}></i>
		    		New Reservation
		    	</Hyperlink>
		    	<Dropdown data={this.props.statuses} placeholder="Change Status" theme="secondary" onChange={this.changeAction}/>
		    	<Hyperlink className="aaui-button aaui-button-secondary aaui-button-size-s link" href={URL.bookingPage}>Modify Booking
		    	</Hyperlink>
		    </div>
		);
	},

	changeAction() {
		console.log(arguments)
	}
});