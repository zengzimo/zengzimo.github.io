"use strict";

export default {
  getPureEvent(event) {
    return {
      id: event.id,
      resourceID: event.resourceID,
      permitStatusDescription: event.permitStatusDescription,
      customerName: event.customerName,
      confirmWaitlistConflict: event.confirmWaitlistConflict,
      startEventDateTime: event.start.toISOString(),
      endEventDateTime: event.end.toISOString(),
      eventName: event.eventName
    }
  },

  getOriginEvent(event) {
    if(!event || !event.source) {
      return;
    }
    let originEvent;
    event.source.origArray.forEach((sevt) => {
      if(sevt.id === event.id){
        originEvent = sevt;
      }
    });
    return originEvent;
  }
}
