"use strict";

import "./ModalContent.less";
import "shared/components/DataGrid/index.less";

import Dropdown from "react-aaui/Dropdown";
import DatePicker from "react-aaui/DatePicker";
import Input from "react-aaui/Input";
import Button from "react-aaui/Button";
import Hyperlink from "shared/components/Hyperlink";
import * as da from "react-aaui/shared/data-access";

export default React.createClass({

  displayName: "ModalContent",

  mixins: [PureRenderMixin],

  getInitialState() {
    return {
      eventName: "",
      eventType: "",
      attendance: "",
      scheduleType: "",
      eventNameEmpty: false,
      events: this.props.data
    }
  },

  componentWillReceiveProps(nextProps) {
    let data = nextProps.data;
    // debugger;
    if (!da.is(data, this.state.events)) {
      this.setState({
        eventName: "",
        eventType: "",
        attendance: "",
        scheduleType: "",
        events: data
      });
    }
  },

  onSave() {
    let events = [];
    this.state.events.forEach((evt) => {
      events.push({
        id: "radom-" + parseInt(Math.random()*1000, 10),
        resourceID: evt.getIn(["resource", "id"]),
        eventName: this.state.eventName,
        startEventDateTime: evt.getIn(["start"]).toISOString(),
        endEventDateTime: evt.getIn(["end"]).toISOString(),
        customerName: "Bill Xiong",
        permitStatusDescription: "Unapproved"
      });
    });
    flux.dispatch("resources.saveBookingEvents", {
      events: events
    });
    this.props.onClose();
  },

  onEventDelete(index) {
    this.setState({
      events: this.state.events.delete(index)
    });
  },

  onEventNameChange(e) {
    let value = e.target.value;
    if(value !== this.state.eventName) {
      this.setState({
        eventName: value
      });
    }
  },

  onAttendanceChange(e) {
    let value = e.target.value;
    if(value !== this.state.attendance) {
      this.setState({
        attendance: value
      });
    }
  },

  onEventChange(event, index) {
    this.setState({
      events: this.state.events.update(index, () => event)
    });
  },

  render() {
    let eventItems = this.state.events.map((event, index) => {
      return <ModalContentEventItem event={event}
        index={index}
        onEventChange={this.onEventChange}
        onEventDelete={this.onEventDelete}/>
    });

    return (
      <div className="booking-resources-modal">
        <div className="aaui-modal-body">
          <section>
            <h3>Event Information</h3>
            <div className="line">
              <label>* Event Name</label>
              <Input value={this.state.eventName} onChange={this.onEventNameChange} placeholder="Enter event name" size="m" style={{width: "400px"}}/>
            </div>
            <div className="line">
              <label>* Event Type</label>
              <Dropdown value={this.state.eventType} data={[]}/>
            </div>
            <div className="line">
              <label>* Attendance</label>
              <Input value={this.state.attendance} onChange={this.onAttendanceChange} placeholder="Enter Attendance" size="m" style={{width: "400px"}}/>
            </div>
            <div className="line">
              <label>* Schedule Type</label>
              <Dropdown value={this.state.scheduleType} data={[]}/>
            </div>
          </section>
          <section>
            <h3>Booking Detail</h3>
            <table className="aaui-table">
              <colgroup>
                <col width="25%"/>
                <col width="65%"/>
                <col width="7%"/>
                <col width="3%"/>
              </colgroup>
              <thead className="aaui-table-header">
                <tr>
                  <td>RESOURCE</td>
                  <td>DATE & TIME</td>
                  <td>QTY</td>
                  <td></td>
                </tr>
              </thead>
              <tbody className="aaui-table-body">
                {eventItems}
              </tbody>
            </table>
          </section>
        </div>
        <div className="aaui-modal-footer">
          <Button type="secondary" onClick={this.onSave}>Save and Add More</Button>
          <Hyperlink href="permitDetail"><Button type="strong" onClick={this.props.onClose}>Proceed to Permit Details</Button></Hyperlink>
        </div>
      </div>
    );
  }

});

/**
 * Dynamic events show.
 * Each event row records all its changes and
 * notice these changes to its parent as a integrated event.
 */
let ModalContentEventItem = React.createClass({

  displayName: "ModalContentEventItem",

  mixins: [PureRenderMixin],

  getInitialState() {
    let event = this.props.event;
    return this.getStates(event);
  },

  componentWillReceiveProps(nextProps) {
    let event = nextProps.event;
    if (!da.is(event, this.state.event)) {
      this.setState(this.getStates(event));
    }
  },

  getStates(event) {
    return {
      event: event,
      start: event.getIn(["start"]),
      end: event.getIn(["end"]),
      resourceName: event.getIn(["resource", "resourceName"])
    }
  },

  onDelete() {
    this.props.onEventDelete(this.props.index);
  },

  onStartDateChange(e) {
    let targetMoment = moment(e);
    if(targetMoment.format("MM/DD/YYYY") !== this.state.start.format("MM/DD/YYYY")){
      let dateClone = this.state.start.clone();
      dateClone.set("year", e.getFullYear());
      dateClone.set("month", e.getMonth());
      dateClone.set("date", e.getDate());
      let event = this.state.event.set("start", dateClone);
      this.props.onEventChange(event, this.props.index);
    }
  },

  onEndDateChange(e) {
    let targetMoment = moment(e);
    if(targetMoment.format("MM/DD/YYYY") !== this.state.end.format("MM/DD/YYYY")){
      let dateClone = this.state.end.clone();
      dateClone.set("year", e.getFullYear());
      dateClone.set("month", e.getMonth());
      dateClone.set("date", e.getDate());
      let event = this.state.event.set("start", dateClone);
      this.props.onEventChange(event, this.props.index);
    }
  },

  onStartTimeChange(e) {
    if(e.target.value !== this.state.start.format("h:mm a")){
      let event = this.state.event.set("start", this.state.start.clone().time(e.target.value));
      this.props.onEventChange(event, this.props.index);
    }
  },

  onEndTimeChange(e) {
    if(e.target.value !== this.state.start.format("h:mm a")){
      let event = this.state.event.set("end", this.state.end.clone().time(e.target.value));
      this.props.onEventChange(event, this.props.index);
    }
  },

  render() {
    return (
      <tr className="aaui-table-row">
        <td><a href="javascript: void(0)">{this.state.resourceName}</a></td>
        <td>
          <DatePicker defaultValue={this.state.start.toDate()} onChange={this.onStartDateChange} style={{width: "100px", marginRight: "4px"}}/>
          <Input value={this.state.start.format("h:mm a")} onChange={this.onStartTimeChange} style={{width: "90px", marginRight: "4px"}}/>
          --
          <DatePicker defaultValue={this.state.end.toDate()} onChange={this.onEndDateChange} style={{width: "100px", margin: "0px 4px"}}/>
          <Input value={this.state.end.format("h:mm a")} onChange={this.onEndTimeChange} style={{width: "90px"}}/>
        </td>
        <td><Input value="1" style={{width: "35px"}}/></td>
        <td><a onClick={this.onDelete}><i className="icon remove-icon"></i></a></td>
      </tr>
    );
  }
});
