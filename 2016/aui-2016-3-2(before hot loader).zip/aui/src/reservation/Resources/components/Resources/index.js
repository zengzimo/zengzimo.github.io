"use strict";

import "./Resources.less";
import "./OverrideFullCalendar.less";

import {OrderedMap, Map, fromJS} from "immutable";
import ReactDOM from "react-dom";
import Modal from "react-aaui/Modal";
import Button from "react-aaui/Button";
import Dropdown from "shared/components/Dropdown/Dropdown";
import Fullcalendar from "shared/components/Fullcalendar";
import ModalContent from "../ModalContent";
import EventHelper from "../../utils/EventHelper.js";

export default React.createClass({

  displayName: "Resources",

  mixins: [PureRenderMixin],

  getInitialState() {
    return {
      isModalDisplayed: false,
      modalData: fromJS([]),
      showBusinessHours: false
    }
  },

  openModal() {
    this.setState({
      isModalDisplayed: true
    });
  },

  closeModal() {
    this.setState({
      isModalDisplayed: false
    });
  },

  onShowBusinessHours() {
    this.setState({
      showBusinessHours: !this.state.showBusinessHours
    });
  },

  onSelect(segs, jsEvent) {
    let filterSegs = segs.filter((seg) => {
      return seg.resource ? true : false;
    });
    if(!filterSegs.length){
      return;
    }
    this.setState({
      modalData: fromJS(segs)
    });
    this.openModal();
  },

  onEventDrop(event) {
    flux.dispatch("resources.moveBookingEvent", EventHelper.getPureEvent(event));
  },

  /**
   * We just have two type of event status - Firm and Pending.
   * @param  {Object} event - no immutable.
   * @return {Object} event - no immutable.
   */
  onEventDataTransform(event) {
    event.id = event.id ? event.id : (event.transactionID + event.permitNumber);
    event.start = event.startEventDateTime;
    event.end = event.endEventDateTime;
    event.color = event.confirmWaitlistConflict ? "#D1F0C9" : "#FEF196";
    event.borderColor = event.confirmWaitlistConflict ? "#afe8a0" : "#ead441";
    return event;
  },

  onEventAfterRender(event, element) {
    let originEvent = EventHelper.getOriginEvent(event);
    if(originEvent.permitStatusDescription){
      element.prepend($([
        "<div class='fc-rs-event-status'>",
          "<b>Status: </b>",
          originEvent.permitStatusDescription,
        "</b></div>"
      ].join("")));
    }
    if(originEvent.customerName){
      element.prepend($([
        "<div class='fc-rs-event-owner'><b>",
          originEvent.customerName,
        "</b></div>"
      ].join("")));
    }
    if(originEvent.eventName){
      element.prepend($([
        "<div class='fc-rs-event-name'><b>",
          originEvent.eventName,
        "</b></div>"
      ].join("")));
    }
  },

  onSitesSelected(newSites) {
    flux.dispatch("resources.fetchResourcesBySites", newSites);
  },

  onResourcesSelected(selectedResources) {
    flux.dispatch("resources.addReources", selectedResources);
  },

  onDeleteResource(resource) {
    //return false to disable Fullcalendar's delete behavior.
    //use react way to refesh view.
    flux.dispatch("resources.deleteReource", resource);
    return false;
  },

  onDeleteAllResources() {
    flux.dispatch("resources.deleteAllReources");
  },

  render() {
    let header = {
      left: "today prev,next title",
      right: "resourceDay,resourceWeek,resourceMonth"
    };

    return (
      <section className="booking-resources">
        <header className="fixup-header">
          <h2>Resource Calendar</h2>
          <Button size="s" disabled={true}>
            <i className="icon list-icon"></i>
          </Button>
          <Button size="s" disabled={true}>
            <i className="icon cart-icon"></i>
          </Button>
        </header>
        <div className="fixup-content">
          {this.props.data.get("loading") ? (<span className="loading-show"><i className="icon loading-spin-icon"></i></span>) : undefined}
          <div className="booking-oprations-bar">
            <Dropdown
              allTxt = "All sites"
              showCheckbox={true}
              placeholder="Site name"
              style={{width: "150px"}}
              onChange={this.onSitesSelected}
              value={this.props.data.get("sitesValues")}
              data={this.props.data.getIn(["sites"]).map(st => {
                  st = st.set("text", st.get("name"));
                  st = st.set("value", st.get("id"));
                  return st;
                })
              }/>
            <Dropdown placeholder="Center name" value="" data={[]} disabled={true} style={{width: "150px"}}/>
            <Dropdown placeholder="Facility" value="" data={[]} disabled={true} style={{width: "150px"}}/>
            <Dropdown
              allTxt = "All resources"
              showCheckbox={true}
              style={{width: "280px"}}
              placeholder="Choose resources"
              onChange={this.onResourcesSelected}
              value={this.props.data.get("chooseResourcesValues")}
              disabled={this.props.data.getIn(["chooseResources"]).count() ? false : true}
              data={this.props.data.getIn(["chooseResources"]).map(rs => {
                  rs = rs.set("text", rs.get("resourceName"));
                  rs = rs.set("value", rs.get("resourceID"));
                  return rs;
                })
              }/>
            <div className="booking-bar-btns">
              <Button size="s" disabled={
                this.props.data.getIn(["newEvents"]).count() ? false : true
              }>
                Bookings({this.props.data.getIn(["newEvents"]).count()})
              </Button>
            </div>
          </div>
          <Modal title="Booking Information" shown={this.state.isModalDisplayed} onClose={this.closeModal}>
            <ModalContent data={this.state.modalData} onClose={this.closeModal}></ModalContent>
          </Modal>
          <Fullcalendar
            header={header}
            views={{
              resourceDay: {
                buttonText: "Day"
              },
              resourceWeek: {
                buttonText: "Week"
              },
              resourceMonth: {
                buttonText: "Month"
              }
            }}
            defaultView="resourceDay"
            defaultDate="2015-03-08"
            selectWireframeShow={true}
            minTime="01:00:00"
            maxTime="24:00:00"
            slotDuration="00:15:00"
            slotLabelInterval="01:00:00"
            snapDuration="0:15:00"
            businessHours={{
              start: "08:00:00",
              end: "18:00:00"
            }}
            firstDay={1}
            contentHeight={530}
            editable={true}
            selectable={true}
            eventLimit={true}
            timeFormat="h:mm A"
            slotLabelFormat="h(:mm) A"
            resourceIdField="resourceID"
            showHeaderRsClose={true}
            renderHeaderRsClose={() => {
              return "<i class='icon remove-icon'></i>";
            }}
            headerRsCloseClick={this.onDeleteResource}
            renderHeaderRsItem={(resource, isAllowed) => {
              return ["<div class='resource-state rs-state-",
                  resource.resourceType,
                  "' title='",
                  resource.resourceName.replace(/'/g, "&#039"),
                "'>",
                    "<span class='rs-state-icon rs-state-icon-",
                      resource.resourceType,
                    "'>",
                      resource.resourceType.slice(0, 1).toLocaleUpperCase(),
                    "</span> " +
                    resource.resourceName +
              "</div>"].join("");
            }}
            noResourceHeadText="No resources Selected."
            renderHeaderAxis={() => {
              return "<span class='icon delete-icon'></span>";
            }}
            select={this.onSelect}
            eventDrop={this.onEventDrop}
            eventMouseover={this.onEventMouseover}
            eventAfterRender={this.onEventAfterRender}
            headerAxisClick={this.onDeleteAllResources}
            eventDataTransform={this.onEventDataTransform}
            events={this.props.data.getIn(["events"])}
            resources={this.props.data.getIn(["resources"])}
            showBusinessHours={this.state.showBusinessHours}
          ></Fullcalendar>
        </div>
        <footer className="fixup-footer">
          <div className="cal-ftr-oprs">
            <Button size="xs" onClick={this.onShowBusinessHours} style={{width: "140px"}}>
              {this.state.showBusinessHours ? "Show full day" : "Show business hours"}
            </Button>
            <Button size="xs" disabled={true}>Export to PDF</Button>
          </div>
          <div className="cal-ftr-status">
            <span><i className="icon circle-icon booking-icon-firm"></i> Firm</span>
            <span><i className="icon circle-icon booking-icon-pending"></i> Pending</span>
          </div>
        </footer>
      </section>
    );
  }

});
