"use strict";

import "./app.less";
import "./store";

flux.dispatch("render.resources");
flux.dispatch("resources.fetchCalendarDate");