"use strict";

import {Store, addStore} from "aflux";
import {fromJS} from "immutable";
import QAjax from "shared/libs/QAjax";
import URL from "shared/libs/url" ;
import renderRoot from "shared/components/Root";
/* view */
import Resources from "./components/Resources";

const store = new Store();
let data = fromJS({
  events: [], resources: [],
  sites: [], sitesValues: "",
  chooseResources: [], chooseResourcesValues: "",
  newEvents: [], loading: false
});

addStore(store);

store.on("render.resources", (dataView) => {
  data = dataView ? dataView : data;
  renderRoot(Resources, data);
});

/**
 * Fetch events and resources.
 */
store.on("resources.fetchCalendarDate", () => {
  QAjax(
    URL.sites,
    function(response) {
      data = data.merge({
        "sites": fromJS(response)
      });
      flux.dispatch("render.resources", data);
    },
    function(xhr) {
      //error
      flux.dispatch("render.resources", data);
      console.log("Fetch resources failed!");
    }
  );

  // QAjax(
  //   URL.events,
  //   function(response) {
  //     data = data.merge({
  //       "events": fromJS(response)
  //     });
  //     flux.dispatch("render.resources", data);
  //   },
  //   function(xhr) {
  //     //error
  //     flux.dispatch("render.resources", data);
  //     console.log("Fetch events failed!");
  //   }
  // );
  //
});


/**
 * Save booking events.
 * @param  {Object} dataView - not immutable.
 * because the events come from fullcalendar is not pure, different with inital data.
 * example: {
 * 		events: [...],
 * 		pormise: ...
 * }
 */
store.on("resources.saveBookingEvents", (dataView) => {
  //Add new booked events to events rendered on Calednar.
  data = data.updateIn(["events"], list => {
    return list.concat(fromJS(dataView.events))
  });
  //Add new booked events to newEvents rendered on Booking button.
  data = data.updateIn(["newEvents"], list => {
    return list.concat(fromJS(dataView.events))
  });
  flux.dispatch("render.resources", data);
});

/**
 * Move a event that existed in Calendar.
 * @param  {Object} eventView - not immutable.
 * because the events come from fullcalendar is not pure, different with inital data.
 */
store.on("resources.moveBookingEvent", (eventView) => {
  data = data.updateIn(["events"], events => {
    return events.map((evt) => {
      return evt.get("id") === eventView.id ? fromJS(eventView) : evt;
    });
  });
  flux.dispatch("render.resources", data);
});

/**
 * Add a reosource and put it into Calendar.
 * @param  {Array} resources - immutable.
 */
store.on("resources.addReources", (resources) => {
  data = data.updateIn(["resources"], list => {
    resources.forEach((rs) => {
      if(!list.includes(rs)){
        list = list.unshift(rs);
      }
    });
    list = list.filter(item => {
      return resources.includes(item) ? true : false;
    });
    return list;
  });
  data = data.set("chooseResourcesValues",
    resources.map(rs => rs.get("resourceID")).toJS().join(","));

  QAjax(
    {
      url: URL.events,
      params: {
        resource_ids: resources.map(st => st.get("resourceID")).join(",")
      }
    },
    function(response) {
      data = data.set("events", fromJS(response));
      flux.dispatch("render.resources", data);
    },
    function(xhr) {
      //error
      flux.dispatch("render.resources", data);
      console.log("Fetch events failed!");
    }
  );

  flux.dispatch("render.resources", data);
});

/**
 * Delete all reosource from Calendar.
 */
store.on("resources.deleteReource", (resource) => {
  data = data.updateIn(["resources"], list => {
    return list.filter((rs) => {
      return rs.get("resourceID") != resource.resourceID ? true : false;
    });
  });
  let chooseResourcesValues = data.get("chooseResourcesValues").split(",");
  data = data.set("chooseResourcesValues",
    chooseResourcesValues.filter(v => v == resource.resourceID ? false : true).join(","));
  flux.dispatch("render.resources", data);
});

/**
 * Delete all reosource from Calendar.
 */
store.on("resources.deleteAllReources", () => {
  data = data.updateIn(["resources"], list => {
    return fromJS([]);
  });
  data = data.set("chooseResourcesValues", "");
  flux.dispatch("render.resources", data);
});

/**
 * Fetch reosources by specifed sites.
 * @param  {Array} sites - immutable.
 */
store.on("resources.fetchResourcesBySites", (sites) => {
  updateLoading(true);
  if(!sites.count()){
    data = data.set("resources", fromJS([]));
    data = data.set("chooseResources", fromJS([]));
    data = data.set("sitesValues", "");
    data = data.set("chooseResourcesValues", "");
    updateLoading(false);
    flux.dispatch("render.resources", data);
  }else {
    QAjax(
      {
        url: URL.resources,
        params: {
          sites: sites.map(st => st.get("id")).join(",")
        }
      },
      function(response) {
        data = data.set("chooseResources", fromJS(response));
        data = data.set("sitesValues", sites.map(st => st.get("id")).toJS().join(","));
        updateLoading(false);
        flux.dispatch("render.resources", data);
      }, function(xhr) {
        flux.dispatch("render.resources", data);
        updateLoading(false);
        console.log("Fetch resources failed!");
      }
    );
  }
});

function updateLoading(state) {
  data = data.set("loading", state ? true : false);
}
