"use strict";

import {Store, addStore} from "aflux";
import {fromJS} from "immutable";
import QAjax from "shared/libs/QAjax";
import renderRoot from "shared/components/Root";
import PermitDetail from "./components/PermitDetail";

const store = new Store();

export let data = [];
let ind = 0;

store.on("render.permitDetail", (dataView) => {
  data = dataView ? dataView : data;
  renderRoot(PermitDetail, data);
});


store.on("permits.siteName", (callback) => {
	QAjax(
		"/json/PermitDetail/siteName.json", 
		function(response) {
			console.log(response.result);
			callback(response.result);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});


store.on("permits.centerName", (callback) => {
	QAjax(
		"/json/PermitDetail/centerName.json",
		function(response) {
			callback(response.result);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});


store.on("permits.resourceType", (callback) => {
	QAjax(
		"/json/PermitDetail/resourceType.json",
		function(response) {
			callback(response.result);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});

store.on("permits.resource", (callback) => {
	QAjax(
		"/json/PermitDetail/resource.json",
		function(response) {
			callback(response.result);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});

store.on("permits.fee", () => {
	QAjax(
		"/json/PermitDetail/fee.json",
		function(response) {
			data = fromJS(response.result);
			flux.dispatch("render.permitDetail", data);
		}, function(xhr) {
			console.log("xhr.status : "+xhr.status)
			console.log("xhr.statusText : "+xhr.statusText)
		}
	);
});


addStore(store);
