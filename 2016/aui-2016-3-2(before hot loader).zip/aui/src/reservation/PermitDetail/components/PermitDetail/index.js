"use strict";

import "./Root.less";
import AAUIButton from "react-aaui/Button";
import AAUIDropdown from "react-aaui/Dropdown";
import DatePicker from "shared/components/DatePicker/DatePicker";
import Button from "react-aaui/Button";
import CustomerQuestion from "../CustomerQuestion/index";
import ChooseCustomerAndCompany from "../ChooseCustomerAndCompany/index";
import Waiver from "../Waiver/index";
import Notes from "../Notes/index";
import Fee from "../Fee/index";
import BasicSearch from "../BasicSearch/index";
import Hyperlink from "shared/components/Hyperlink";
import CartList from "shared/components/PopList";
import {fromJS} from "immutable";



export default React.createClass({
  displayName: "Root",

  mixins: [PureRenderMixin],

  openWindow: null,

  getInitialState: function() {
    return {
      isExpand: false,
      dateVal: "",
      isShowDatepicker: false,
      customerName: "",
      customerNameLabel:"Search customer",
      companyName: "",
      companyNameLabel:"Search company",
      isShowDialog: false
    };
  },

  render() {
    const data = [
      {text: "Normal permit", value: "Normal permit"},
      {text: "Tentative", value: "Tentative"},
      {text: "Temporary", value: "Temporary"}
    ];


    const feeData = fromJS([
                      {
                        "feeItem": "Party Room #3",
                        "date":"2015 Dec 21   8:00 AM  -  2015 Dec 25   8:00 PM",
                        "amount":"200",
                        "detail" : [
                                    {
                                      "feeItem": "Charge name 1",
                                      "qty":"2",
                                      "unitCharge":"80",
                                      "amount":"160"
                                    },
                                     {
                                      "feeItem": "Charge name 2",
                                      "qty":"1",
                                      "unitCharge":"40",
                                      "amount":"40"
                                    }
                                   ]
                      },
                      {
                        "feeItem": "Party Room #3",
                        "date":"2015 Dec 21   8:00 AM  -  2015 Dec 25   8:00 PM",
                        "amount":"200",
                        "detail" : [
                                    {
                                      "feeItem": "Charge name 1",
                                      "qty":"2",
                                      "unitCharge":"80",
                                      "amount":"160"
                                    },
                                     {
                                      "feeItem": "Charge name 2",
                                      "qty":"1",
                                      "unitCharge":"40",
                                      "amount":"40"
                                    }
                                   ]
                      }
                    ]);
    var cartData = fromJS([{"name":"reservation #1","price":200},{"name":"reservation #2","price":201},{"name":"reservation #3","price":202}]);
    

    const waiver = [
                    {"desc":"Checklist item name 1", "type":"Facility"},
                    {"desc":"Membership item ", "type":"Membership"},
                    {"desc":"Facility Facility", "type":"Facility"}
                  ];
    return (
      <section className="facilityReservation">
        <div className="box spaceBetween">
          <h2 className="title">Permit Detail</h2>

          <span className="alignSelf permitType">
            <AAUIDropdown data={data} placeholder="Choose permit type" className="permitTypeSelect" onChange={this.dropdownChange}></AAUIDropdown>
            <div className={ this.state.isShowDatepicker ? "expirationDate" : "aaui-hidden"}>
                <span> Expiration date </span>
                <span>{this.state.dateVal}</span>
                <DatePicker className="datePicker" iconModel="true" onChange={this.showDateValue}/>
            </div>
          </span>
          <span className="alignSelf">
            <CartList reservations={cartData} total={603} iconClassName="cart-icon"></CartList> 
          </span>
        </div>
        <BasicSearch />
        <ChooseCustomerAndCompany />
        <CustomerQuestion />
        <Waiver data={waiver}/>
        <Notes />
        <Fee data={feeData}/>

        <div className="box spaceBetween marginTop">
          <AAUIButton   onClick={(e) => console.log(e)}>Cancel Booking</AAUIButton>
          <div className="backBtn"> <AAUIButton  onClick={(e) => console.log(e)}>Back</AAUIButton></div>
          <a href="/cart"><AAUIButton type="primary">Add to Cart</AAUIButton></a>
        </div>
      </section>
    );
  },
  dropdownChange(obj){
      let isShowDatepicker = false;
      if(obj.value !== "Normal permit"){
          isShowDatepicker = true;
      }
      this.setState({
        isShowDatepicker: isShowDatepicker
      });
  },
  showDateValue(val){
      this.setState({
        dateVal: val.toDateString()
      });
  },
  expand(){
    this.setState({
      isExpand: !this.state.isExpand
    });
  }
});
