"use strict";

import {fromJS} from "immutable";
import "./Fee.less";
import Modal from "react-aaui/Modal";
import Button from "react-aaui/Button";
import EventInformation from "../EditBooking/EventInformation";
import BookingDetail from "../EditBooking/BookingDetail";

export default React.createClass({
  displayName: "Fee",

  mixins: [PureRenderMixin],

  render() {
    return (
            <div className="wrapper fee" ref="fee">
              <div className="box spaceBetween">
                <h3 className="sectionTitle">Fee</h3>
                <span>
                  <a className="link editBooking" onClick={this.editBooking}> <i className="icon edit-icon"></i>Edit booking</a>
                  <a className="link"> <i className="icon plus-icon"></i>Add new charge</a>
                </span>
              </div>
              <Modal title="Edit Booking" shown={this.state.isShowEditBooking} onClose={this.closeEditBooking}>
                <div className="aaui-modal-body">
                    <EventInformation />
                    <BookingDetail />
                </div>
                <div className="aaui-modal-footer">
                  <Button type="strong" onClick={this.close}>OK</Button>
                </div>
              </Modal>
              <ul className="feeItem">
                <li className="sectionHeader">
                    <div>FEE ITEMS</div>
                    <div>DATE & TIME</div>
                    <div>QTY</div>
                    <div>UNIT CHARGE</div>
                    <div>AMOUNT</div>
                    <div></div>
                    <div>ACTION</div>
                </li>
                {
                  this.state.dataView.map((item, i) => {
                      return (
                          <div key={"totalItem" + i}>
                              <li className="lightLi">
                                <div><a className="link">{item.get("feeItem")}</a></div>
                                <div>{item.get("date")}</div>
                                <div></div>
                                <div></div>
                                <div>$ {item.get("amount")}</div>
                                <div><i className={ this.state.liState.get("isExpand"+i) ? "icon angle-up-icon" : "icon angle-down-icon"}  onClick={this.expand.bind(this, i)}></i></div>
                                <div><i className="icon delete-icon"></i></div>
                            </li>
                            <li className={ this.state.liState.get("isExpand"+i) ? "itemDetail" : "itemDetail aaui-hidden"}>
                                <ul>
                                    {
                                      item.get("detail").map((obj, index) => {
                                            return (
                                              <li className="lightLi" key={"detailItem" + index}>
                                                  <div><a className="link">{obj.get("feeItem")}</a></div>
                                                  <div></div>
                                                  <div>{obj.get("qty")}</div>
                                                  <div>$ {obj.get("unitCharge")}</div>
                                                  <div>$ {obj.get("amount")}</div>
                                                  <div/>
                                                  <div><a><i className="icon edit-icon"></i> <i className="icon delete-icon"></i></a></div>
                                              </li>
                                            )
                                        }

                                      )
                                    }
                                </ul>
                            </li>
                          </div>
                        )
                  })
                }
              </ul>
              <ul className="summaryFee">
                  <li>
                    <div></div>
                    <div>Subtotal:</div>
                    <div>$260.00</div>
                  </li>
                  <li>
                    <div></div>
                    <div>Transaction Fee:</div>
                    <div>$2.50</div>
                  </li>
                  <li>
                    <div></div>
                    <div>PST:</div>
                    <div>$2.50</div>
                  </li>
                  <li>
                    <div></div>
                    <div>GST:</div>
                    <div>$5.50</div>
                  </li>
                  <li className="totalFee">
                  <div><Button type="strong" onClick={this.showCover}>test</Button></div>
                    <div></div>
                    <div>TOTAL</div>
                    <div>$270.00</div>
                  </li>
              </ul>
              <div className={this.state.showCover ? "fee-cover": "aaui-hidden"} style={{height: this.state.coverHeight + 'px'}}>
                  <div className="cover-info">Fee is updated, click refresh to check detail.</div>
                  <div><Button type="strong" onClick={this.refresh}>Refresh</Button></div>
              </div>
            </div>
    );
  },
  getInitialState() {
    let data = this.props.data || [];
    let liState = {};
    data.map((item, index) => {
      liState["isExpand" + index] = false;
    });

    return {
      dataView: data,
      liState: fromJS(liState),
      isShowEditBooking: false,
      showCover: false,
      coverHeight: 300
    };
  },
  expand(index){
    this.setState({
      liState: this.state.liState.set("isExpand" + index, !this.state.liState.get("isExpand" + index))
    });
  },
  editBooking() {
    this.setState({
      isShowEditBooking: true
    });
  },
  closeEditBooking() {
    this.setState({
      isShowEditBooking: false
    });
  },
  showCover() {
    let feeDiv = React.findDOMNode(this.refs.fee);
    this.setState({
      showCover: !this.state.showCover,
      coverHeight: feeDiv.scrollHeight
    });
  },
  refresh() {
    this.setState({
      showCover: false
    });
  }
});
