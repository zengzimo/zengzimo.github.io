"use strict";

import "./ChooseCustomerAndCompany.less";
import AAUIButton from "react-aaui/Button";
import AAUIDropdown from "react-aaui/Dropdown";
import Hyperlink from "shared/components/Hyperlink";



export default React.createClass({
  displayName: "ChooseCustomerAndCompany",

  mixins: [PureRenderMixin],

  openWindow: null,

  getInitialState: function() {
    return {
      customerName: "",
      customerNameLabel:"Search customer",
      companyName: "",
      companyNameLabel:"Search company",
      isShowDialog: false
    };
  },

  render() {
    const cc = [
      {text: "Customer", value: "customer"},
      {text: "Company", value: "company"}
    ];
    return (
      <section className="chooseCustomerAndCompany">
        <div className="wrapper">
          <h3 className="sectionTitle">Choose Customer/Company</h3>
          <div className={ !this.state.isShowAgent ? "contentWrapper customer" : "aaui-hidden"}>
              <span>Type</span>
              <span><AAUIDropdown data={cc} value="customer" className="permitTypeSelect" onChange={this.changeCustomerType}></AAUIDropdown></span>
              <span> {this.state.customerName} </span>
              <span><a className="link" onClick={this.customerSearch}>{this.state.customerNameLabel}</a></span>
          </div>
          <div className={ this.state.isShowAgent ? "" : "aaui-hidden"}>
              <div className="contentWrapper customer">
                  <span>Type</span>
                  <span><AAUIDropdown data={cc}  value="company" className="permitTypeSelect" onChange={this.changeCustomerType}></AAUIDropdown></span>
                  <span> {this.state.companyName} </span>
                  <span><a className="link" onClick={this.searchCompany}>{this.state.companyNameLabel}</a></span>
              </div>
              <div className="contentWrapper customer">
                  <span>Agent</span>
                  <span><AAUIDropdown placeholder="Agent name" data={[]} className="permitTypeSelect"></AAUIDropdown></span>
              </div>
          </div>
        </div>
      </section>
    );
  },
  searchCustomer(){
      let customerNameLabel = "Change customer";
      let customerName = "Nolan";
      this.setState({
        customerName: customerName,
        customerNameLabel:  customerNameLabel
      });
  },
  searchCompany(){
      let companyNameLabel = "Change company";
      let companyName = "Active Network";
      this.setState({
        companyName: companyName,
        companyNameLabel: companyNameLabel
      });
  },
  changeCustomerType(obj){
      let isShowAgent = false;
      if(obj.value === "company"){
          isShowAgent = true;
      }
      this.setState({
        isShowAgent: isShowAgent
      });
  },
  customerSearch(){
    let url = "http://localhost:8080/web/adminSelect.sdi?oc=Customer&class_name=Permit&permit_id=22&sdireqauth=1453795331473";
    let _self = this;
    window.returnSelectedCustomer = function(id, name){
      _self.openWindow.close();
      _self.setState({
        customerName: name,
        customerNameLabel:  "Change customer"
       });
    };
    this.openWindow = window.open(url,'newwindow','height=700,width=900,top=200,left=700,toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no, status=no') 
  }
});
