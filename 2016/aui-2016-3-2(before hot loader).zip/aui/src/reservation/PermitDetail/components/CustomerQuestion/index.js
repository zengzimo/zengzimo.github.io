"use strict";

import "./CustomerQuestion.less";
import AAUIDropdown from "react-aaui/Dropdown";
import AAUIRadio from "react-aaui/Radio";
import Hyperlink from "shared/components/Hyperlink";



export default React.createClass({
  displayName: "CustomerQuestion",

  mixins: [PureRenderMixin],

  render() {
    return (
        <div className="wrapper customerQuestion">
          <h3 className="sectionTitle">Customer Question</h3>
          <div className="contentWrapper">
            <div className="box qustionItem">
              <div>1. </div>
              <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
              <div>
                  <ul className="question">
                    <li><AAUIRadio name="a" value="1">oque penatibus et magnis</AAUIRadio></li>
                    <li><AAUIRadio name="a" value="2">oque penatibus parturient montes</AAUIRadio></li>
                    <li><AAUIRadio name="a" value="3">oque penatibus et magnis dis</AAUIRadio></li>
                    <li><AAUIRadio name="a" value="4">turient montes</AAUIRadio></li>
                  </ul>
              </div>
            </div>
            <div className="box qustionItem">
              <div>2. </div>
              <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</div>
              <div><AAUIDropdown data={[]} placeholder="Answer1" className="permitTypeSelect"></AAUIDropdown></div>
            </div>
          </div>
        </div>
    );
  }
});