"use strict";

import "./Waiver.less";
import AAUICheckbox from "react-aaui/Checkbox";



export default React.createClass({
  displayName: "Waiver",

  mixins: [PureRenderMixin],

  render() {
    return (
         <div className="wrapper waiver">
          <h3 className="sectionTitle">Waiver</h3>
          <ul>
            <li className="sectionHeader">
                <div>WAIVER DESCRIPTION</div>
                <div></div>
                <div></div>
                <div></div>
            </li>
              {
                  this.props.data.map((item, i) => {
                      return (
                          <li key={item.desc} className="lightLi">
                              <div><a className="link desc">{item.desc}</a> <span className="type_facility">{item.type}</span></div>
                              <div><a className="link"><i className="icon pencil-icon"></i> Sign your name</a></div>
                              <div><a className="link"><i className="icon txt-icon"></i> View attachment</a></div>
                              <div><i className="icon required-icon"></i><AAUICheckbox></AAUICheckbox> Agree to waiver</div>
                          </li>
                        )
                  })
              }
              <li className="lightLi" style={{padding:0}}>
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </li>
          </ul>
        </div>
    );
  }
});