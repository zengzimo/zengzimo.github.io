"use strict";

import "./Notes.less";


export default React.createClass({
  displayName: "Notes",

  mixins: [PureRenderMixin],

  getInitialState: function() {
    return {
      isExpand: false
    };
  },

  render() {
    return (
        <div className="wrapper notes">
          <div className="box spaceBetween noteHeader">
            <h3 className="sectionTitle">Notes</h3>
            <span className={ this.state.isExpand ? '' : 'aaui-hidden'} onClick={this.expand}><i className="icon minus-icon"></i></span>
            <span className={ this.state.isExpand ? 'aaui-hidden' : ''} onClick={this.expand}><i className="icon plus-icon"></i></span>
          </div>
          <div className={ this.state.isExpand ? 'noteSection' : 'aaui-hidden'}>
            <div className="noteItem">
              <label className="label-title">Permit Note</label>  <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet.</span>
            </div>
            <div className="noteItem">
              <label className="label-title">Event Type Notes</label>  <span className="label-title">Event Type: Meeting</span>
            </div>
            <div className="noteItem">
              <label></label>  <span>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet.</span>
            </div>
            <div className="noteItem">
              <label className="label-title">Preparation Notes</label>  <span>Dolor sit amet Lorem ipsum</span>
            </div>

            <div className="noteItem">
              <label>Staff Note</label>  <textarea></textarea>
            </div>
            <div className="noteItem">
              <label>Customer Note</label>  <textarea rows="3" cols="20"></textarea>
            </div>
          </div>
        </div>
    );
  },
  expand() {
    this.setState({
      isExpand: !this.state.isExpand,
    });
  }
});
