"use strict";

import "./BasicSearch.less";
import * as da from "react-aaui/shared/data-access";
import {fromJS} from "immutable";
import Dropdown from "shared/components/Dropdown/Dropdown";
import Checkbox from "react-aaui/Checkbox";


export default React.createClass({
    displayName: "BasicSearch",

    mixins: [PureRenderMixin],

    getInitialState() {
        return {
            siteName: [],
            centerName: [],
            resourceType: [],
            resource: [],
            siteNameVals: "",
            centerNameVals: "",
            resourceTypeVals: "",
            resourceVals: "",
            showError: true,
            showSpiner: true,
            testVals:"",
            errorInfo:""
        };
    },
    componentWillMount: function() {
        flux.dispatch("permits.siteName", (data) => {
              this.setState({
                                siteName: fromJS(data),
                                showSpiner: false
                            });
            // var self = this;
            // window.setTimeout(function(){
            //                self.setState({
            //                     siteName: fromJS(data),
            //                     showSpiner: false,
            //                 });
            // }, 5000);
 
        });

        flux.dispatch("permits.resourceType", (data) => {
            this.setState({
                resourceType: fromJS(data)
            });
        });
    },
    render() {
        let data = [
                    {"text":"siteName","value":"12","age":11, "name":"123"},
                    {"text":"siteName11","value":"112","age":11, "name":"123"},
                    {"text":"siteName22","value":"122","age":11, "name":"123"},
                    {"text":"siteName33","value":"123","age":11, "name":"123"},
                    {"text":"siteName44","value":"124","age":11, "name":"123"},
                    {"text":"siteName55","value":"125","age":11, "name":"123"},
                    {"text":"siteName66","value":"1y2","age":11, "name":"123"},
                    {"text":"siteName77","value":"1f12","age":11, "name":"123"},
                    {"text":"siteName22","value":"1f22","age":11, "name":"123"},
                    {"text":"siteName33","value":"12h3","age":11, "name":"123"},
                    {"text":"siteName44","value":"12w4","age":11, "name":"123"},
                    {"text":"siteName55","value":"1e25","age":11, "name":"123"}
                  ];
        let testData = [{"age":11, "name":"111111","type":"equipment"},{"age":12, "name":"222222","type":"facility"},
        {"age":13, "name":"333333","type":"instructor"}];
        let data1 = fromJS({"sites": testData});
        return ( < div className = "wrapper basicSearch" >

                     < Dropdown data = {data}
                                placeholder = {"fdsafdsafdsa"}
                                value = {this.state.testVals}
                                onChange = {this.testChange}> 
                     < /Dropdown>

                     < Dropdown data = {
                                data1.updateIn(["sites"], list => {
                                    return list.map((st) => {
                                      st = st.set("text", st.get("name"));
                                      st = st.set("value", st.get("age"));
                                      return st;
                                    });
                                  }).getIn(["sites"]) 
                                }
                                placeholder = "Site name"
                                showCheckbox = {true}
                                value = {this.state.testVals}
                                showResults={true}
                                onMenuHide = {this.testHide}>
                    < /Dropdown>


                    < Dropdown 
                                data = {this.state.siteName}
                                placeholder = "Site name"
                                showCheckbox = {true}
                                value = {this.state.siteNameVals}
                                allTxt = "All sites"
                                className = "serachDropdown"
                                showResults={true}
                                showSpiner={this.state.showSpiner}
                                onChange = {this.siteNameChange} 
                                onMenuHide = {this.testHide}
                                results = {() => {
                                        return(
                                            <div className="dropdown-results">{ "100 results" }</div>
                                        );
                                    }
                                }
                                showError = {this.state.showError}
                                errorInfo = {this.state.errorInfo}
                                errorInfoTemplate= {() => {
                                        return(
                                            <div className="dropdown-error">{ this.state.errorInfo }</div>
                                        );
                                    }
                                }
                                itemTemplate = {(data,ccs,isCheck,click) => { 
                                    return (
                                          <li key={da.get(data, "value")} className={ccs()}>
                                                <Checkbox checked={isCheck()} 
                                                        onClick={() => {
                                                            click(da.get(data, "value"));
                                                        }}> {da.get(data, "text")} 
                                                </Checkbox>
                                                <span className={"icon-"+ da.get(data, "type")}>
                                                    {da.get(data, "type").charAt(0).toUpperCase()}
                                                </span>
                                          </li>
                                     )} 
                                    }

                                ajaxLoading = {this.ajaxLoading}
                            > 
                    < /Dropdown> 
                    < Dropdown data = {this.state.centerName}
                                placeholder = "Center name"
                                showCheckbox = {true}
                                value = { this.state.centerNameVals}
                                allTxt = "All center"
                                className = "serachDropdown"
                                onChange = {this.centerNameChange} >
                    < /Dropdown> 

                    < div > 
                        < Dropdown data = {this.state.resourceType}
                                    placeholder = "All resources type"
                                    showCheckbox = {true}
                                    value = {this.state.resourceTypeVals}
                                    allTxt = "All resources type"
                                    className = "serachDropdown doubleDropdown"
                                    onChange = {this.resourceTypeChange} >
                        < /Dropdown> 

                        < span className = "verticalGap" > < /span > 

                        < Dropdown data = {this.state.resource}
                            placeholder = "Choose resources"
                            showCheckbox = {true}
                            value = {this.state.resourceVals}
                            allTxt = "All resources"
                            className = "serachDropdown doubleDropdown"
                            onChange = {this.resourceChange} >
                        < /Dropdown> 
                    < /div > 
                < /div>
    );
},
ajaxLoading(){
    this.setState({
        showSpiner: true,
        showError: false
    });
    var self = this;
    window.setTimeout(function(){
                   self.setState({
                        showSpiner: false,
                        showError: true
                    });
    }, 5000);
},
getList: function(value, dataView) {
    let values = value.split(",");
    let len = values.length;
    let result = [];
    for (let i = 0; i < len; i++) {
        if(values[i] == "") continue;
        result = result.concat(dataView[values[i]]);
    }
    return result;
},
filterValues: function(val1, val2, dataView) {
    var value1Array = val1.split(",");
    var value2Array;
    var result = "";
    for (var key in value1Array) {
        value2Array = dataView[value1Array[key]];
        for (var item in value2Array) {
            if (val2.indexOf(value2Array[item].value) > -1) {
                result = result + value2Array[item].value + ","
            }
        }
    }
    result = result.substr(0, result.length - 1);
    console.log(result);
    return result;
},
getValuesFromCheckedItems: function(checkedItems){
    let value = "";
    checkedItems.map((item) => {
        if(item){
            value = value + item.value + ",";
        }
    });
    return value.substr(0, value.length -1);
},  

testChange: function(obj) {
    console.log(obj);
    let value = this.getValuesFromCheckedItems(obj);
    console.log("siteNameChange============" + value);
     this.setState({
                testVals: value
            });
},

testHide: function() {
    console.log("onMenuHide");
},

siteNameChange: function(obj) {
    if(obj.size > 2) {
        this.setState({
                errorInfo: "50 resources at most."
        });
    } else if(this.state.errorInfo != ""){
        this.setState({
                errorInfo: ""
        })
    }
    // console.log(obj);
    // let value = this.getValuesFromCheckedItems(obj);
    // console.log("siteNameChange============" + value);
    // flux.dispatch("permits.centerName", (data) => {
    //     console.log("siteNameResponse============" + data);
    //     if (value === "") {
    //         this.setState({
    //             centerName: [],
    //             siteNameVals: "",
    //             centerNameVals: ""
    //         });
    //     } else {
    //         this.setState({
    //             centerName: fromJS(this.getList(value, data)),
    //             siteNameVals: value,
    //             centerNameVals: this.filterValues(value, this.state.centerNameVals, data)
    //         });
    //     }
    // });
},
centerNameChange: function(obj) {
    let value = this.getValuesFromCheckedItems(obj);
    console.log("centerNameChange============" + value);

    if (value === "") {
        this.setState({
            centerNameVals: "",
        });
    } else {
        this.setState({
            centerNameVals: value
        });
    }
},
resourceTypeChange: function(obj) {
    let value = this.getValuesFromCheckedItems(obj);
    console.log("resourceTypeChange============" + value);

    flux.dispatch("permits.resource", (data) => {
        console.log("resourceResponse============" + data);
        if (value === "") {
            this.setState({
                resource: [],
                resourceTypeVals: "",
                resourceVals: ""
            });
        } else {
            this.setState({
                resource: fromJS(this.getList(value, data)),
                resourceTypeVals: value
            });
        }
    });
},
resourceChange: function(obj) {
    let value = this.getValuesFromCheckedItems(obj);
    console.log("resourceChange============" + value);
    this.setState({
        resourceVals: value
    });
}
});
