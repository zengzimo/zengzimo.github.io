"use strict";

import "./EventInformation.less";
import Dropdown from "react-aaui/Dropdown";
import Input from "react-aaui/Input";
import Label from "react-aaui/Label";

export default React.createClass({
  displayName: "EventInformation",

  mixins: [PureRenderMixin],

  render() {
    return (
      <section className="eventInformation">
        <div className="title">Event Information</div>
        <div className="content">
             <div className="">
                <Label for="eventName"><span className="icon required-icon"></span>Event Name</Label>
                <Input id="eventName" defaultValue="Hello World!" />
             </div>
             <div className="">
                <Label for="eventType"><span className="icon required-icon"></span>Event Type</Label>
                <Dropdown id="eventType" data={[]} class="dropdownWidth permitTypeSelect"/>
            </div>
             <div className="">
                <Label for="attendance"><span className="icon required-icon"></span>Attendance</Label>
                <Input id="attendance" defaultValue="Hello World!"  />
            </div>
            <div className="">
                <Label for="st"><span className="icon required-icon"></span>Shchedule Type</Label>
                <Dropdown id="st" data={[]}  class="dropdownWidth"/>
            </div>
        </div>
      </section>
    );
  }
});
