"use strict";

import "./BookingDetail.less";
import DatePicker from "react-aaui/DatePicker";
import Input from "react-aaui/Input";

const rows = [
                {
                  check: "",
                  resourceName: "facility",
                  unit: "Day",
                  date: {startDate: "11/30/2015", startTime: "6:00 AM",endDate: "12/31/2015", endTime: "6:00 PM" },
                  qty: 1,
                  atnd: 2,
                  eventType: {
                    value: 1,
                    datasource: [{text: "Day event", value: 1}, {text: "Week event", value: 2}, {text: "Month event", value: 3}]
                  }
                },
                {
                  check: "check",
                  resourceName: "facility2",
                  unit: "Month",
                  date: {startDate: "11/30/2015", startTime: "6:00 AM",endDate: "12/31/2015", endTime: "6:00 PM" },
                  qty: 1,
                  atnd: 2,
                  eventType: {
                    value: 3,
                    datasource: [{text: "Day event", value: 1}, {text: "Week event", value: 2}, {text: "Month event", value: 3}]
                  }
                },
                {
                  check: "",
                  resourceName: "facility3",
                  unit: "Year",
                  date: {startDate: "11/30/2015", startTime: "6:00 AM",endDate: "12/31/2015", endTime: "6:00 PM" },
                  qty: 1,
                  atnd: 2,
                  eventType: {
                    value: 3,
                    datasource: [{text: "Day event", value: 1}, {text: "Week event", value: 2}, {text: "Month event", value: 3}]
                  }
                },
                {
                  check: "",
                  resourceName: "facility",
                  unit: "Day",
                  date: {startDate: "11/30/2015", startTime: "6:00 AM",endDate: "12/31/2015", endTime: "6:00 PM" },
                  qty: 1,
                  atnd: 2,
                  eventType: {
                    value: 1,
                    datasource: [{text: "Day event", value: 1}, {text: "Week event", value: 2}, {text: "Month event", value: 3}]
                  }
                },
                {
                  check: "check",
                  resourceName: "facility2",
                  unit: "Month",
                  date: {startDate: "11/30/2015", startTime: "6:00 AM",endDate: "12/31/2015", endTime: "6:00 PM" },
                  qty: 1,
                  atnd: 2,
                  eventType: {
                    value: 3,
                    datasource: [{text: "Day event", value: 1}, {text: "Week event", value: 2}, {text: "Month event", value: 3}]
                  }
                },
                {
                  check: "",
                  resourceName: "facility3",
                  unit: "Year",
                  date: {startDate: "11/30/2015", startTime: "6:00 AM",endDate: "12/31/2015", endTime: "6:00 PM" },
                  qty: 1,
                  atnd: 2,
                  eventType: {
                    value: 3,
                    datasource: [{text: "Day event", value: 1}, {text: "Week event", value: 2}, {text: "Month event", value: 3}]
                  }
                },
                {
                  check: "",
                  resourceName: "facility",
                  unit: "Day",
                  date: {startDate: "11/30/2015", startTime: "6:00 AM",endDate: "12/31/2015", endTime: "6:00 PM" },
                  qty: 1,
                  atnd: 2,
                  eventType: {
                    value: 1,
                    datasource: [{text: "Day event", value: 1}, {text: "Week event", value: 2}, {text: "Month event", value: 3}]
                  }
                }
              ];

export default React.createClass({
  displayName: "BookingDetail",

  mixins: [PureRenderMixin],

  getInitialState() {
    return {
      dataView: rows
    };
  },

  render() {
    return (
      <section className="bookingDetail">
        <div className="title">Booking Detail</div>
        <div className="">
          <table>
            <thead>
                <tr>
                  <th>RESOURCE</th>
                  <th>DATE&TIME</th>
                  <th>QTY</th>
                  <th></th>
                </tr>
            </thead>
            <tbody>
                {
                  this.state.dataView.map(function (data, index) {
                      return <tr key={data.resourceName + index}>
                                <td>
                                  <a className="link">{data.resourceName}</a>
                                </td>
                                <td>
                                     <DatePicker value={ new Date(data.date.startDate)}></DatePicker>
                                     <Input  defaultValue={data.date.startTime} />
                                     --
                                     <DatePicker  value={new Date(data.date.endDate)}></DatePicker>
                                     <Input   defaultValue={data.date.endTime} />
                                </td>
                                <td>
                                    <Input className="qty" defaultValue={data.qty}/>
                                </td>
                                <td>
                                    <i className="icon delete-icon"></i>
                                </td>
                            </tr>
                  }.bind(this))
                }
            </tbody>
          </table>
        </div>
      </section>
    );
  }
});
