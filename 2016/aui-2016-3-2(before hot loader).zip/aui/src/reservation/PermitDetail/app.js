"use strict";

import "./app.less";
import "shared/libs/iframe";
import "./store";


flux.dispatch("render.permitDetail");

