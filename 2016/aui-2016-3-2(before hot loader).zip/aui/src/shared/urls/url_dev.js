export const permits = ROOT_URL + "/json/permits_default.json";

export const sites = ROOT_URL + "/json/sites.json";

export const centers = ROOT_URL + "/json/centers.json";

export const events = ROOT_URL + "/json/events.json";

export const resources = ROOT_URL + "/json/resources.json";

export const bookingPage = ROOT_URL + "/resources";
