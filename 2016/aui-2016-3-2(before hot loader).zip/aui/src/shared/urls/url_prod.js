export const permits = ROOT_URL + "/permit.do?method=loadPermits";

export const sites = ROOT_URL + "/permit.do?method=loadSites";

export const centers = ROOT_URL + "/permit.do?method=loadCenters";

export const status = ROOT_URL + "/permit.do?method=loadStatus";

export const events = ROOT_URL + "/resource.do?method=loadResourceBookings";

export const resources = ROOT_URL + "/resource.do?method=loadResources";

export const bookingPage = ROOT_URL + "/resource.do?method=booking";
