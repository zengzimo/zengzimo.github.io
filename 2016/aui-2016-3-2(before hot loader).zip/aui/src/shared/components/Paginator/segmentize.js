'use strict';

var intersect = require('intersect');

module.exports = function(o) {
     var page = o.currentPage;
    var pages = o.totalPages;
    var showPages = o.showPages;
    var beginMax = Math.floor(showPages/2);
    var beginPages = range(beginMax);
    var endMin = pages - (showPages - beginMax) + 1;
    var endPages = range(endMin, pages);
    var center, ret, centerLen;
    var intersectLen = 0;
    var diff = 0;

    if(showPages >= pages) {
        return [range(pages)];
    }

    if(page === 1 || page === pages) {
        ret = [beginPages, endPages].filter((a) => a.length);
        return ret;
    }

    center = [page - 1, page, page + 1];
    centerLen = center.length;
    console.log('beginPages: ')
    console.log(beginPages)
     console.log("endPages")
      console.log(endPages)
    if(intersectLen = intersect(beginPages, center).length) {
        beginPages = range(Math.max.apply(null, beginPages.concat(center)))
        diff =  centerLen - intersectLen
        endPages = (endPages.length > diff) && endPages.splice(0, diff) && endPages
        center = [];
    }

    if(intersectLen = intersect(center, endPages).length) {
        endPages = range(Math.min.apply(null, center.concat(endPages)), pages)
            diff =  centerLen - intersectLen
        beginPages = diff && (beginPages.length > diff) && beginPages.splice(-diff) && beginPages || beginPages
        center = [];
    }
    
    if (!center.length) {
    return [beginPages, endPages]
    }
    if(center[0] - beginPages.slice(-1)[0] === 1) {
        return [beginPages.concat(center), endPages];
    }

    if(endPages[0] - center.slice(-1)[0] === 1) {
        return [beginPages, center.concat(endPages)];
    }

    return [beginPages, center, endPages].filter((a) => a.length);
};

function difference(a, b) {
    return a.filter((v) => b.indexOf(v) < 0);
}

function range(a, b) {
    var ret = [];
    var i = b? a: 1;
    var len = b? b: a;

    for(; i <= len; i++) {
        ret.push(i);
    }

    return ret;
}