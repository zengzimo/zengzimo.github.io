'use strict';
import './index.less';
var paginateAction = require('./paginateAction');
var segmentize = require('./segmentize');

export default React.createClass({
    displayName: 'Paginator',
    mixins: [PureRenderMixin],
    propTypes: {
        onSelect: React.PropTypes.func,
        currentPage: React.PropTypes.number,
        totalPages: React.PropTypes.number,
        showPages: React.PropTypes.number,
        showPrevNext: React.PropTypes.bool,
        alwaysShowPrevNext: React.PropTypes.bool,
        className: React.PropTypes.string,
        ellipsesClassName: React.PropTypes.string,
        prevClassName: React.PropTypes.string,
        nextClassName: React.PropTypes.string,
        activeClassName: React.PropTypes.string,
        inactiveClassName: React.PropTypes.string,
        prevButton: React.PropTypes.node,
        nextButton: React.PropTypes.node
    },
    getDefaultProps() {
        return {
            onSelect: function() {},
            currentPage: 1,
            showPages: 10,
            showPrevNext: false,
            className: 'aaui-pagination',
            ellipsesClassName: '',
            prevClassName: 'aaui-pagination-prev',
            nextClassName: 'aaui-pagination-next',
            activeClassName: 'selected',
            inactiveClassName: 'disabled'
        };
    },
    render() {
        var {
            onSelect,
            currentPage, //currentPage从1开始计
            totalPages,
            ellipsesClassName,
            className,
            showPrevNext,
            alwaysShowPrevNext,
            prevClassName,
            nextClassName,
            activeClassName,
            inactiveClassName
        } = this.props;

        var segments = segmentize(this.props);
        segments = segments.reduce(function(a, b) {
            return a.concat(-1).concat(b);
        });

        var items = segments.map((num, i) => {
            if (num > 0) {
                return (
                    <li key={'pagination-' + i} onClick={onSelect.bind(null, num)} className={num === currentPage && activeClassName || ''}>
                        {num}
                    </li>
                );
            }

            return (
                <li key={'pagination-' + i} className={ellipsesClassName}>
                    &hellip;
                </li>
            );
        });

        var lastPage = segments[segments.length - 1];

        var isFirstPage = currentPage === 1;
        var isLastPage = currentPage === lastPage;

        prevClassName += paginateAction.maybeAddInactive(isFirstPage, alwaysShowPrevNext, inactiveClassName);
        nextClassName += paginateAction.maybeAddInactive(isLastPage, alwaysShowPrevNext, inactiveClassName);

        var prevButton = (
            <li onClick={onSelect.bind(null, paginateAction.prev(currentPage))}
                className={prevClassName}>
                {this.props.prevButton ? this.props.prevButton : 'Previous'}
            </li>
        );

        var nextButton = (
            <li onClick={onSelect.bind(null, paginateAction.next(currentPage, lastPage))}
                className={nextClassName}>
                {this.props.nextButton ? this.props.nextButton : 'Next'}
            </li>
        );

        return (
            <ul className={className}>
                {(alwaysShowPrevNext || (showPrevNext && !isFirstPage)) && prevButton}
                {items}
                {(alwaysShowPrevNext || (showPrevNext && !isLastPage)) && nextButton}
            </ul>
        );
    }
});


