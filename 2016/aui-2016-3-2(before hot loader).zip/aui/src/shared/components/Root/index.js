"use strict";
import ReactDOM from "react-dom";

let Root = React.createClass({
  displayName: "App",
  mixins: [PureRenderMixin],

  render() {
    const Module = this.props.view;
    return (
      <Module data={this.props.data}/>
    );
  },
});

export default function (view, data) {
	ReactDOM.render(<Root view={view} data={data}/>, document.getElementById("app-root"));
}
 
