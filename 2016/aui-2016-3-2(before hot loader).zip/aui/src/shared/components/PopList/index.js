"use strict";

import "./PopList.less";
import IconButton from "../IconButton";
import Button from "react-aaui/Button";
import Hyperlink from "../Hyperlink";

export default React.createClass({
    displayName: "PopList",
    mixins: [PureRenderMixin],

    render() {
        const {title, className, iconClassName} = this.props;
        
        return (
            <IconButton className={`pop-list ${className ? className : ''}`} title={title} iconClassName={iconClassName}>
                {this.renderContent()}
            </IconButton>
        );
    },

    renderContent() {
        let {children, data, emptyMessage, href, total} = this.props;
        let childDoms = []

        if (children) return children;

        if (data) {
            if (data.size) {
                childDoms.push(<ul>
                    {data.map((item, key) => {
                        return (
                            <li key={key}>
                                <span>{item.get('name')}</span>
                                <span className="price">${item.get('price')}</span>
                            </li>
                        );
                    })}
                </ul>)   
            } else {
                childDoms.push(<div className="empty-wrapper">{emptyMessage}</div>);
            }
            if (href) {
                childDoms.push(<Hyperlink className="aaui-button aaui-button-strong aaui-button-size-s" href={href}>View Cart ${total}</Hyperlink>);
            }
            return childDoms
        }
    },

    getDefaultProps() {
        return {
            emptyMessage: "No permits in cart",
        };
    }
});
