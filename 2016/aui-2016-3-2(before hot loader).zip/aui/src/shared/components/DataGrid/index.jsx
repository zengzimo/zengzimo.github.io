import "./index.less";
import Paginator from "shared/components/Paginator";
import * as da from "react-aaui/shared/data-access";

export default React.createClass({
	displayName: 'Table',
    mixins: [PureRenderMixin],
    render() {
        return (
            <div>
            	<table className="aaui-table">
            		<thead className="aaui-table-header">
                        <tr>{this.headerRender()}</tr>
            		</thead>
            		<tbody className="aaui-table-body">
            			{this.props.data.map((row, key) => {
                            return (
                                <tr key={key} className="aaui-table-row">
                                {this.props.columns.map((column, k) => {
									let width = da.get(column, "width");
									let cellContent = da.get(row, da.get(column, "name"));
									let columnRender = da.get(column, "render");
									columnRender = typeof columnRender === "function" && columnRender;
                                	return (
                                        <td key={k} className={da.get(column, "cellClassName") || ""} style={{width: width ? width  : "auto"}}>
                                        {columnRender ? columnRender.call(this, cellContent, key) : <div className="aaui-table-cell">{cellContent}</div>}
                                        </td>
                                    )
                        		})}
                                </tr>
                            );
                        })}
            		</tbody>
            		{this.props.children}
            	</table>
                {this.props.pagination ? <Paginator onSelect={this.onSelect} {...this.props.pagination}/> : ""}
            </div>
        )
    },

    getDefaultProps() {
        return {
            pagination: {
                totalPages: 1,
                currentPage: 1
            }
        }
    },

    headerRender() {
        return this.props.columns.map((item, key) => {
            return (
                <th key={key} className={`aaui-table-column ${da.get(item, "className")|| ""}`} style={{width: da.get(item, "width") ? da.get(item, "width") : "auto"}}>
                    {da.get(item, "renderHeader") ? da.get(item, "renderHeader").call(this, item, key) : this.headerCell(item, key)}
                </th>
            );
        })
    },

    headerCell(item, key) {
        let sort =  da.get(item, "sort");
		let title = da.get(item, "title");
        if (sort) {
            let asc = sort === "asc";
            return (
                <div>
                    <span>{title}</span>
                    <span className="aaui-table-sort">
                        <i className={`icon aaui-table-sort-asc ${asc ? "active" : ""}`} onClick={this.onSort.bind(this, item, key, "asc")}></i>
                        <i className={`icon aaui-table-sort-desc ${asc ? "" : "active"}`} onClick={this.onSort.bind(this, item, key, "desc")}></i>
                    </span>
                </div>
            )
        }
        return title;
    },

    onSelect(curPage) {
        if (this.props.onChange) this.props.onChange(curPage)
    },

    onSort(column, key, sortDirection) {
        if (this.props.onSort) this.props.onSort(column, key, sortDirection)
    }
})
