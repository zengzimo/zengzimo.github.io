"use strict";

import "./IconButton.less";
import Button from "react-aaui/Button";
import Hyperlink from "shared/components/Hyperlink";

export default React.createClass({
    displayName: "IconButton",
    mixins: [PureRenderMixin],

    render() {
        const {className, title, children} = this.props;
        
        return (
            <div className={`icon-button-wrapper ${className ? className : ''}`} title={title ? title : ''} onClick={this.toggleCartList}>
                {this.renderIcon()}
                {this.renderChildren(children)}
            </div>
        );
    },

    getInitialState() {
        return {
            className: "aaui-hidden"
        }
    },

    toggleCartList() {
        let className = this.state.className ? "" : "aaui-hidden"
        this.setState({
            className: className
        });
    },

    renderIcon() {
        const {isIconLink, link, iconClassName} = this.props;

        if (isIconLink) return <Hyperlink className={`icon ${iconClassName}`} href={link}></Hyperlink>;
        return <i className={`icon ${iconClassName}`}></i>;
    },

    renderChildren(children) {
        if (children) return <div className={`popup ${this.state.className}`}>{children}</div>
    }
});
