"use strict";

import React from "react";
import PureRenderMixin from "react-addons-pure-render-mixin";
import ReactDOM from "react-dom";
import "react-aaui/DatePicker.less";
import Input from "react-aaui/Input";

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const DAY_SPAN = 1000 * 60 * 60 * 24;

export default React.createClass({
  displayName: "AAUIDatePicker",
  mixins: [PureRenderMixin],

  render() {
    const calendarDate = this.state.calendarDate;
    const calendarDateStr = `${MONTH_NAMES[calendarDate.getMonth()]} ${calendarDate.getFullYear()}`;
    const days = this.findOutDays(calendarDate);
    const today = new Date();

    return (
      <div className={`aaui-datepicker ${this.props.className || ""}`} style={this.props.style}>
        {
          this.props.iconModel ? (
              <span className="icon calendar-icon" onClick={
                this.props.onFocus
                  ? e => {
                    this.gainFocus();
                    this.props.onFocus(e);
                  }
                  : this.gainFocus
              }>{"\uf073"}</span>
           ) : undefined}
            <Input
                ref="input"
                style={{display: "none"}}
                name={this.props.name}
                postText={this.props.showIcon ? "\uf073" : undefined}
                errored={this.props.errored}
                disabled={this.props.disabled}
                defaultValue={
                  (this.props.value && this.formatDate(this.state.value)) ||
                  (this.props.defaultValue && this.formatDate(this.props.defaultValue))
                }
                onFocus={
                  this.props.onFocus
                    ? e => {
                      this.gainFocus();
                      this.props.onFocus(e);
                    }
                    : this.gainFocus
                }
                onBlur={
                  this.props.onBlur
                    ? e => {
                      this.loseFocus();
                      this.props.onBlur(e);
                    }
                    : this.loseFocus
                }
                onClick={this.displayIfNotAlready}/>
        <div className={this.calendarClass()} onMouseDown={this.preventStealingFocus}>
          <header className="aaui-datepicker-header aaui-clearfix">
            <span
              className="aaui-icon-left-arrow aaui-datepicker-left-arrow"
              title="Previous month"
              onClick={this.goPrevMonth}></span>
            <span
              className="aaui-icon-right-arrow aaui-datepicker-right-arrow"
              title="Next month"
              onClick={this.goNextMonth}></span>
            <h1 className="aaui-datepicker-calendar-title">{calendarDateStr}</h1>
          </header>
          <table className="aaui-datepicker-table">
            <thead>
              <tr>
                <th title="Sunday">S</th>
                <th title="Monday">M</th>
                <th title="Tuesday">T</th>
                <th title="Wednesday">W</th>
                <th title="Thursday">T</th>
                <th title="Friday">F</th>
                <th title="Saturday">S</th>
              </tr>
            </thead>
            <tbody>
              {days.map((r, i) => {
                return (
                  <tr key={i}>
                    {r.map((c, j) => {
                      let cls = "";
                      if (this.isOtherMonth(c)) cls += " aaui-datepicker-other-month";
                      if (this.isSameDay(c, today)) cls += " aaui-datepicker-today";
                      if (this.isSelectedDate(c)) cls += " aaui-datepicker-selected";
                      return (
                        <td key={j} className={cls} onClick={this.selectDate.bind(this, days[i][j])}>
                          {c.getDate()}
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    );
  },

  componentDidMount() {
    Object.defineProperties(this, {
      value: {
        get() {
          return this.state.value;
        },
        set(v) {
          if (this.props.value === undefined) {
            this.setState({value: v});
          }
        }
      },
    });
  },

  componentDidUpdate() {
    this.refs.input.value = this.formatDate(this.state.value);
  },

  componentWillReceiveProps(nextProps) {
    const newState = {
      value: nextProps.value !== this.props.value
        ? nextProps.value
        : nextProps.defaultvalue !== this.props.defaultvalue
          ? this.state.value === undefined
            ? nextProps.defaultvalue
            : this.state.value
          : this.state.value
    };
    if (newState.value !== this.state.value) this.setState(newState);
  },

  getInitialState() {
    return {
      isDisplayed: false,
      showOnTop: false,
      showOnLeft: false,
      value: this.props.value || this.props.defaultValue,
      calendarDate: this.props.value || this.props.defaultValue || new Date(),
    };
  },

  gainFocus() {
    const rect = ReactDOM.findDOMNode(this.refs.input).getBoundingClientRect();
    const verDistance = document.documentElement.clientHeight -
      (rect.top + rect.height);
    const horDistance = document.documentElement.clientWidth -
      (rect.left + rect.width);

    this.setState({
      isDisplayed: true,
      showOnTop: verDistance < 216.75 && rect.top >= 216.75,
      showOnLeft: horDistance < 246 && rect.width <= 246,
      calendarDate: this.state.value || new Date(),
    });
  },

  loseFocus() {
    const input = this.refs.input;
    const value = this.state.value;
    const d = new Date(input.value);

    if (isNaN(d.getTime())) {
      // Invalid date, reset input.
      input.value = this.formatDate(value);
    } else if (value && d.getTime() !== value.getTime()) {
      this.selectDate(d);
    }

    this.setState({
      isDisplayed: false,
    });
  },

  selectDate(d) {
    const date = this.props.value !== undefined ? this.state.value : d;

    this.setState({
      value: date,
      isDisplayed: false,
    }, () => {
      if (this.props.onChange) this.props.onChange(d);
    });
  },

  calendarClass() {
    let cls = "aaui-datepicker-calendar";
    if (!this.state.isDisplayed) cls += " aaui-hidden";
    if (this.state.showOnTop) cls += " aaui-datepicker-calendar-show-on-top";
    if (this.state.showOnLeft) cls += " aaui-datepicker-calendar-show-on-left";
    return cls;
  },

  goPrevMonth() {
    const calendarDate = this.state.calendarDate;
    const prevMonth = new Date(
      new Date(calendarDate.getFullYear(), calendarDate.getMonth(), 1).getTime() - DAY_SPAN
    );
    this.setState({
      calendarDate: prevMonth
    });
  },

  goNextMonth() {
    const calendarDate = this.state.calendarDate;
    const nextMonth = new Date(
      new Date(calendarDate.getFullYear(), calendarDate.getMonth(), 1).getTime() + DAY_SPAN * 31
    );
    this.setState({
      calendarDate: nextMonth
    });
  },

  preventStealingFocus(e) {
    e.preventDefault();
  },

  isSameDay(x, y) {
    return x.getFullYear() === y.getFullYear() &&
      x.getMonth() === y.getMonth() &&
      x.getDate() === y.getDate();
  },

  isSelectedDate(d) {
    const value = this.state.value;
    if (!value) return false;
    return d.getFullYear() === value.getFullYear() &&
      d.getMonth() === value.getMonth() &&
      d.getDate() === value.getDate();
  },

  isOtherMonth(d) {
    return d.getMonth() !== this.state.calendarDate.getMonth();
  },

  findOutDays(d) {
    const firstDayOfMonth = new Date(d.getFullYear(), d.getMonth(), 1);
    const startDate = firstDayOfMonth.getTime() - DAY_SPAN * firstDayOfMonth.getDay();

    let days = new Array(6);
    for (let i = 0; i < 6; i++) {
      days[i] = new Array(7);
      for (let j = 0; j < 7; j++) {
        days[i][j] = new Date(startDate + (i * 7 + j) * DAY_SPAN);
      }
    }
    return days;
  },

  formatDate(d) {
    if (d == null) return "";
    return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
  },

  displayIfNotAlready() {
    if (document.activeElement === this.refs.input.refs.input
        && !this.state.isDisplayed) {
      this.setState({isDisplayed: true});
    }
  },
});
