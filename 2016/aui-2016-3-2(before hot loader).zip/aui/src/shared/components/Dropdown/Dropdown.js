"use strict";

import React from "react";
import PureRenderMixin from "react-addons-pure-render-mixin";
import {cls} from "react-aaui/shared/utils";
import {pipe} from "func.js";
import {OrderedMap,Iterable} from "immutable";
import * as da from "react-aaui/shared/data-access";
import "react-aaui/Dropdown.less";
import "./Dropdown.less";
import Item from "./Item.js";
import Checkbox from "react-aaui/Checkbox";

export default React.createClass({
  displayName: "AAUIDropdown",
  mixins: [PureRenderMixin],
  render() {
    const {
      className, style,
      disabled, placeholder,
      maxHeight, name,
      filter, filterPlaceholder,
      theme, errored, showCheckbox , 
      showSpiner, errorInfo,showResults,results,showError, errorInfoTemplate
    } = this.props;
    const {isExpanded, value, dataView, activeItemIndex} = this.state;

    let str = (value) => <div>{value}</div>;

    return (
      <div className={cls`aaui-dropdown ${className || ""}`}
           style={style}>
        <button type="button"
                className={cls`${theme ? `aaui-dropdown-btn-${theme}` : ""}
                            ${isExpanded ? "aaui-dropdown-expanded" : ""}
                            ${disabled ? "aaui-dropdown-disabled" : ""}
                            ${errored ? "aaui-input-errored" : ""}`}
                onClick={disabled ? undefined : this.toggleMenu}>

          {
              showCheckbox ? <div className="aaui-dropdown-btn-text">{this.findMutiTextByValue() || this.props.placeholder}</div> :
              <div className="aaui-dropdown-btn-text">{this.findTextByValue(value) || placeholder}</div>
          }
          <i className={cls`aaui-dropdown-btn-icon
                         ${isExpanded ? "aaui-icon-up-arrow" : "aaui-icon-down-arrow"}`}></i>
        </button>
        <div className={cls`aaui-dropdown-menu ${isExpanded ? "" : "aaui-hidden"}`}>
            <ul
                ref="itemMenu"
                tabIndex="1"
                style={{maxHeight}}
                onKeyDown={this.navigateByKeys}
                onMouseDown={this.giveFocus}
                onFocus={this.cancelCollapseTimeout}
                onBlur={this.tryCollapse}>
              {filter
                ? (
                  <li className="aaui-dropdown-filter aaui-dropdown-divider">
                    <i className="aaui-icon-mag-glass"></i>
                    <input type="text"
                           ref="filterInput"
                           className="aaui-dropdown-filter-input"
                           autoComplete="off"
                           placeholder={filterPlaceholder}
                           onKeyDown={this.handleKeys}
                           onChange={this.applyFilter}/>
                  </li>
                )
                : undefined}

               {showCheckbox && da.count(this.state.dataView) > 0
                ? (
                    <li>
                      <Checkbox checked={this.state.checkAll} onClick={this.checkAll}> {this.props.allTxt || "All"} </Checkbox>
                    </li>
                )
                : undefined
              }
              {dataView.map((item, i) => {
                return (
                  showCheckbox
                  ?(
                    this.props.itemTemplate ? this.decorate(item,i) :
                    <Item key={da.get(item, "value")} data={item} isCheck={this.state.rowState[da.get(item,"value")]} click={this.check} ccs={i === activeItemIndex ? "aaui-dropdown-active-item" : undefined} />
                  ):(
                    <li key={da.get(item, "value")}
                      className={i === activeItemIndex ? "aaui-dropdown-active-item" : undefined}
                      onClick={this.select.bind(this, da.get(item, "value"))}>
                      {da.get(item, "text")}
                  </li>
                  )
                );
              })}
            </ul>
            <div className="menu-footer">

                <div className= {showSpiner ? "dropdown-spiner" : "aaui-hidden"}><i className="icon loading-spiner-icon"></i>{" Loading..."}</div>

                { showError && errorInfo
                  ? (
                        errorInfoTemplate ? errorInfoTemplate() : <div className="dropdown-error">{ errorInfo }</div>
                  )
                  : <div></div>
                }

                {showResults && da.count(dataView) > 0
                  ? (
                        results ? results() : <div className="dropdown-results">{da.count(dataView) + ' results'}</div>
                  )
                  : <div></div>
                }
            </div>
        </div>
        
        <input name={name} type="hidden" value={value}/>
      </div>
    );
  },
  decorate(item,index){
    let isCheck = () => this.state.rowState[da.get(item,"value")];
    let ccs = () => { return index === this.state.activeItemIndex ? "aaui-dropdown-active-item" : undefined};
    return this.props.itemTemplate(item,ccs,isCheck,this.check);
  },
  componentDidMount() {
    Object.defineProperties(this, {
      value: {
        get() {
          return this.state.value;
        },
        set(v) {
          if (this.props.value === undefined) {
            this.setState({value: v});
          }
        }
      },
    });
  },

  componentWillReceiveProps(nextProps) {
    const newState = {};
    if (nextProps.value !== this.props.value) {
      newState.value = nextProps.value;
    } else if (nextProps.defaultValue !== this.props.defaultValue) {
      newState.value = this.state.value === undefined
        ? nextProps.defaultValue
        : this.state.value;
    }
    if (!da.is(nextProps.data, this.props.data)) {
      newState.dataView = nextProps.data;
    }
    if (Object.keys(newState).length > 0) this.setState(newState);
  },

  componentDidUpdate() {
    if (this.state.isExpanded) {
      if (this.props.filter) {
        this.refs.filterInput.focus();
      } else {
        this.refs.itemMenu.focus();
      }

      const activeItem = this.refs.itemMenu.querySelector(".aaui-dropdown-active-item");
      if (activeItem) activeItem.scrollIntoView();
    }
  },

  getDefaultProps() {
    return {
      placeholder: "Select one...",
      filterPlaceholder: "Filter...",
    };
  },

  getInitialState() {
    let rowState ={};
    if(this.props.showCheckbox){
      this.checkboxArray =  OrderedMap({});
      return {
        isExpanded: false,
        value: this.props.value || this.props.defaultValue,
        dataView: this.props.data,
        activeItemIndex: -1,
        rowState:rowState,
        showSpiner: this.props.showSpiner || false,
        errorInfo: this.props.errorInfo,
        checkAll: false
      };
    }else{
      return {
        isExpanded: false,
        value: this.props.value || this.props.defaultValue,
        dataView: this.props.data,
        activeItemIndex: -1
      };
    }
  },
  filterCheckItems(checkes) {
    let vlaue = this.state.value || "";
    let checkboxArray = null;
    checkes.map((item) => {
        if(Object.prototype.toString.call(item) == "[object Object]"){
          checkes.push(item);
        }else{
          if(vlaue.indexOf(item) == -1){
            checkboxArray = this.setCheckboxArray(item,"");
          }
        }
    });
    return checkboxArray == null? checkes : checkboxArray;
  },
  getCheckValue(checkes) {
    let result = "";
    let _self = this;
    checkes.map((item) => {
        if( Object.prototype.toString.call(item) == "[object Object]" ){
          result = result + item.value + ",";
        }else{
          result = result + item + ",";
        }
    });
    return {value: result.substr(0, result.length-1),checkedItems : this.findCheckedItemsByValue(checkes)};
  },
  findCheckedItemsByValue(checkes) {
    if(da.count(this.props.data) == 0)return undefined
    let data = this.props.data.filter((item) => {
      return checkes.get(da.get(item, "value")) !== undefined ? true : false;
    });
    return data;
  },
  findMutiTextByValue(){
    let value = this.props.value || "";
    let values = value.split(",");
    const len = values.length;
    let text = ".";
    return len && values[0] ? (this.props.placeholder + " (" + len + ")") : undefined;
  },
  isAllChecked(){
    const len = this.state.rowState.length;
    for(let item in this.state.rowState){
      if(this.state.rowState[item] == false){
        return false;
      }
    }
    return true;
  },
  setCheckboxArray(key, value){
    if(this.checkboxArray.has(key)){
      if(value == ""){
        this.checkboxArray = this.checkboxArray.delete(key);
      }else{
        this.checkboxArray = this.checkboxArray.update(key, (value) => value);
      }
    }else{
      this.checkboxArray = this.checkboxArray.set(key,value);
    }

    return this.checkboxArray;
  },
  check(val){
    this.state.rowState[val] = !this.state.rowState[val];
    let tempVal = this.state.rowState[val] ? val : "";
    this.checkboxArray = this.setCheckboxArray(val,tempVal);
    let checkedObj = this.getCheckValue(this.checkboxArray);

    this.state.checkAll = !this.state.rowState[val] ? false : this.isAllChecked();
    this.setState({
      value: checkedObj.value,
      isExpanded: true,
      activeItemIndex: -1,
      rowState: this.state.rowState,
      checkAll: this.state.checkAll
    });
    if (this.props.onChange) this.props.onChange(checkedObj.checkedItems);
  },
  getAllValues(){
    if(this.state.checkAll){
      this.props.data.map((item) => {
        this.checkboxArray = this.setCheckboxArray(da.get(item, "value"),da.get(item, "value"));
      });

    } else {
      this.checkboxArray = OrderedMap({});
    }
    return this.checkboxArray;
  },
  checkAll() {
    var rowState ={};
    var checkState = !this.state.checkAll;
    for(var item in this.state.rowState) {
      rowState[item] = checkState;
    }

    this.state.checkAll = checkState;

    let checkedObj = this.getCheckValue(this.getAllValues());

    this.setState({
      value: checkedObj.value,
      rowState: rowState,
      checkAll: this.state.checkAll
    });
    if (this.props.onChange) this.props.onChange(checkedObj.checkedItems);
  },
  resetRowState(){
    let value = this.state.value;
    let rowState = this.state.rowState;
    for(let item in rowState){
        if(value.indexOf(item) == -1){
            rowState[item] = false;
        }
    }
  },
  onMenuHide(){
    this.state.isExpanded ? undefined : this.props.onMenuHide ?  this.props.onMenuHide() : undefined;
  },
  toggleMenu() {
    clearTimeout(this._timer);
    let rowState ={};
    let checkAll = false;
    if(this.props.showCheckbox){
      if(!this.props.value || this.props.value.length == 0){
        var self = this;
        this.refs.itemMenu.onscroll = function(){
           // debugger;
          var height = this.clientHeight;
          var scrollHeight = this.scrollHeight;
          if(scrollHeight - height <= this.scrollTop){
            console.log("ajax loading");
            self.props.ajaxLoading();
          }
          console.log(this.scrollTop);
        }
        this.isFirstToggleMenu = true;
      }
      if(this.isFirstToggleMenu && da.count(this.props.data) > 0){
        this.props.data.map((item, i) => {
          rowState[da.get(item, "value")] = false;
        });
        this.isFirstToggleMenu = false;
      }else{
        this.resetRowState();
        rowState = this.state.rowState;

        if(da.count(this.props.data) > 0) checkAll = this.isAllChecked();
      }
      this.checkboxArray = this.filterCheckItems(this.checkboxArray);
      this.setState({
        isExpanded: !this.state.isExpanded,
        dataView: this.props.data,
        rowState: rowState,
        checkAll: checkAll,
        value: this.state.value
      }, this.onMenuHide);
    }else{
       this.setState({
          isExpanded: !this.state.isExpanded
      });
    }
  },

  tryCollapse(e) {
    if (this.state.isExpanded) {
      this._timer = setTimeout(() => {
        this.setState({
          isExpanded: false
        }, this.onMenuHide);
      }, 150);
    }
  },

  cancelCollapseTimeout() {
    clearTimeout(this._timer);
  },

  giveFocus(e) {
    if (e.target === this.refs.itemMenu) {
      this.refs.itemMenu.focus();
    }
  },

  navigateByKeys(e) {
    e.preventDefault();
    switch (e.keyCode) {
    case 38: // up
      this.setState({
        activeItemIndex: this.state.activeItemIndex - 1 >= 0
          ? this.state.activeItemIndex - 1
          : da.count(this.state.dataView) - 1
      });
      break;
    case 40: // down
      this.setState({
        activeItemIndex: this.state.activeItemIndex + 1 < da.count(this.state.dataView)
          ? this.state.activeItemIndex + 1
          : 0
      });
      break;
    case 13: // enter
      this.select(
        pipe(
          this.state.dataView,
          _ => da.get(_, this.state.activeItemIndex),
          _ => da.get(_, "value")
        )
      );
      break;
    case 27: // escape
      this.setState({
        isExpanded: false,
        activeItemIndex: -1,
      });
      break;
    }
  },

  applyFilter(e) {
    this.setState({
      dataView: this.filterData(e.target.value, this.props.data)
    });
  },

  handleKeys(e) {
    // Delegate up, down, and escape to itemMenu.
    if ([38, 40, 27].indexOf(e.keyCode) > -1) return;
    // Delegate enter to itemMenu if up/down selections are already made.
    if (e.keyCode === 13 && this.state.activeItemIndex > -1) return;
    e.stopPropagation();
  },

  select(value) {
    const val = this.props.value !== undefined ? this.state.value : value;

    this.setState({
      value: val,
      isExpanded: false,
      activeItemIndex: -1,
    }, () => {
      if (this.props.onChange) this.props.onChange({value});
    });
  },

  findItemByValue(value) {
    if(da.count(this.props.data) == 0)return undefined;
    var data = this.props.data.toJS ? this.props.data.toJS() : this.props.data;
    for (let item of data) {
      if (da.get(item, "value") === value) {
        return item;
      }
    }
    return undefined;
  },

  getIn(x, k) {
    return Iterable.isIterable(x) ? x.getIn([k]) : x[k];
  },

  findTextByValue(value) {
    const item = this.findItemByValue(value);
    if (item) {
      return da.get(item, "text");
    } else {
      return undefined;
    }
  },

  filterData(key, dataset) {
    let k = key.trim().toLowerCase();
    let klen = k.length;

    function matcher(item) {
      let t = da.get(item, "text").trim().toLowerCase();
      let i = 0;
      let kc = k.charAt(i);
      for (let tc of t) {
        if (tc === kc) {
          i++;
          if (i >= klen) {
            return true;
          }
          kc = k.charAt(i);
        }
      }
      return false;
    }

    return (!k ? dataset : dataset.filter(matcher));
  },
});
