"use strict";

import React from "react";
import PureRenderMixin from "react-addons-pure-render-mixin";
import * as da from "react-aaui/shared/data-access";
import Checkbox from "react-aaui/Checkbox";

export default React.createClass({
  displayName: "Item",
  mixins: [PureRenderMixin],
  render() {
    const {data,isCheck,ccs,click} = this.props;

    return (
       <li key={da.get(data, "value")} className={ccs}>
          <Checkbox checked={isCheck} 
                    onClick={() => {
                      click(da.get(data, "value"))
                    }}> {da.get(data, "text")} </Checkbox>
      </li>
    );
  }
});