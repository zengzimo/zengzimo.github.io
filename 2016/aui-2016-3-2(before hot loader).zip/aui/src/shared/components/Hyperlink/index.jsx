"use strict";

export default React.createClass({
  displayName: "Hyperlink",

  render() {
    return (
      <a {...this.props}
        href={this.props.href}>{this.props.children}</a>
    );
  }

});
