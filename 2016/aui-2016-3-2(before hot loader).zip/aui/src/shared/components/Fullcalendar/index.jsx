"use strict";

import * as da from "react-aaui/shared/data-access";


export default React.createClass({

	displayName: 'Fullcalendar',

	mixins: [PureRenderMixin],

	/**
	 * allDaySlot is not needed for our system.
	 * so default to false.
	 */
	getDefaultProps() {
		return {
			allDaySlot: false,
			minTime: "01:00:00",
			maxTime: "24:00:00"
		};
	},

	/**
	 * Only need to be update when events and resources property are changed.
	 * <SetEvents> just rerender events part.
	 * <SetResources> will rerender whole current calendar view.
	 */
	componentDidUpdate({events, resources, showBusinessHours}) {
		if(!da.is(resources, this.props.resources)){
			// debugger;
			this.transferCalling("setResources",
				this.props.resources.toJS ?
					this.props.resources.toJS() :
					this.props.resources
			);
		}
		if(!da.is(events, this.props.events)){
			// debugger;
			this.transferCalling("removeEvents");
			this.transferCalling("addEventSource",
				this.props.events.toJS ?
					this.props.events.toJS() :
					this.props.events
			);
		}
		/**
		 * This businessHours is different with fullCalendar's businessHours.
		 * Using minTime and maxTime to implement our requirement.
		 * It's a good way because we don't need to change fullCalendar.
		 */
		if(!da.is(showBusinessHours, this.props.showBusinessHours)){
			let businessHours;
			if(this.props.showBusinessHours){
				businessHours = {
					start: this.props.businessHours.start,
					end: this.props.businessHours.end
				};
			}else{
				businessHours = {
					start: this.props.minTime,
					end: this.props.maxTime
				}
			}
			if(businessHours){
				this.setOption("setOption", "minTime", businessHours.start, false);
				this.setOption("setOption", "maxTime", businessHours.end, true);
			}
		}
	},

	componentDidMount() {
		let settings = $.extend({}, this.props);
		if(!settings.showBusinessHours){
			settings.businessHours = false;
		}
		$(this.refs.calendar).fullCalendar(settings);
	},

	componentWillUnmount() {
		$(this.refs.calendar).remove();
	},

	setOption(...params) {
		let needRerender = params.splice(-1)[0];
		this.transferCalling(...params);
		if(needRerender){
			this.transferCalling("rerender");
		}
	},

	transferCalling(...params) {
		return $(this.refs.calendar).fullCalendar(...params);
	},

	render() {
		return React.createElement("div", {ref: "calendar"});
	}

})
