"use strict";

var gulp = require("gulp");
var webpack = require("webpack");
var extend = require("extend");
var entry = require("./webpack/entry");
var configDev = require("./webpack/config.dev");
var configProd = require("./webpack/config.prod");
var configStatic = require("./webpack/config.static");

var firstTime = true;

gulp.task("build.dev", function(done) {
  var config = extend({}, configDev, {entry: entry.dev});
  runWebpack(config, done);
});

gulp.task("build.prod", function(done) {
  var config = extend({}, configProd, {entry: entry.prod});
  runWebpack(config, done);
});

gulp.task("build.static", function(done) {
  var config = extend({}, configStatic, {entry: entry.static});
  runWebpack(config, done);
});

function runWebpack(config, done) {
  webpack(config, function(err, stats) {
    console.log(stats.toString({colors: true}));
    if (!err && firstTime && done) {
      firstTime = false;
      done();
    }
  });
};
