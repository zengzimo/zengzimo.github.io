"use strict";

var gulp = require("gulp");
var inject = require("gulp-inject");
var changed = require("gulp-changed");
var copyTasks = require("../copy");
var entry = require("../webpack/entry");
var appConfig = require("../app.config");
var rename = require("gulp-rename");

const moduleName = "cart";
const copyModuleName = "copy.module." + moduleName;

function copyFuncWrap(diff) {
  return function(done) {
    return gulp.src("src/reservation/Cart/cart.html")
      .pipe(rename({
        extname: appConfig.getViewExtension(diff)
      }))
      .pipe(changed(appConfig.getPath(diff)))
      .pipe(gulp.dest(appConfig.getPath(diff)))
      .pipe(inject(gulp.src([
        appConfig.getPath(diff, "./css/cart*.css"),
        appConfig.getPath(diff, "./css/commons*.css"),
        appConfig.getPath(diff, "./js/common*.js"),
        appConfig.getPath(diff, "./js/cart*.js"),
      ], {read: false}), {
        relative: true,
        addPrefix: appConfig.getPrefixPath(diff)
      }))
      .pipe(inject(gulp.src([
        ".app.json"
      ], {read: false}), {
        starttag: '<!-- inject:ide-path-def:{{ext}} -->',
        transform: function (filePath, file) {
          return appConfig.getIdePathDef(diff);
        }
      }))
      .pipe(inject(gulp.src([
        ".app.json"
      ], {read: false}), {
        starttag: '<!-- inject:ROOT_URL:{{ext}} -->',
        transform: function (filePath, file) {
          return appConfig.getROOT_URL(diff);
        }
      }))
      .pipe(gulp.dest(appConfig.getPath(diff)));
  }
}

gulp.task(copyModuleName + ".dev", copyFuncWrap("dev"));
gulp.task(copyModuleName + ".prod", copyFuncWrap("prod"));
gulp.task(copyModuleName + ".static", copyFuncWrap("static"));

copyTasks.register(copyModuleName + ".dev", "dev");
copyTasks.register(copyModuleName + ".prod", "prod");
copyTasks.register(copyModuleName + ".static", "static");
entry.register({
  name: moduleName,
  value: "./src/reservation/Cart/app.js"
});
