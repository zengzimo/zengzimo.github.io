"use strict";

var gulp = require("gulp");
var inject = require("gulp-inject");
var changed = require("gulp-changed");
var runSeq = require("run-sequence");
var copyTasks = require("../copy");
var entry = require("../webpack/entry");
var appConfig = require("../app.config");
var rename = require("gulp-rename");

const moduleName = "resources";
const copyModuleName = "copy.module." + moduleName;

gulp.task(copyModuleName + ".dev", function(done) {
  return runSeq("copy.resource.lib.dev", "copy.resource.after.lib.dev", done);
});

gulp.task(copyModuleName + ".prod", function(done) {
  return runSeq("copy.resource.lib.prod", "copy.resource.after.lib.prod", done);
});

gulp.task(copyModuleName + ".static", function(done) {
  return runSeq("copy.resource.lib.static", "copy.resource.after.lib.static", done);
});

copyTasks.register(copyModuleName + ".dev", "dev");
copyTasks.register(copyModuleName + ".prod", "prod");
copyTasks.register(copyModuleName + ".static", "static");
entry.register({
  name: moduleName,
  value: "./src/reservation/Resources/app.js"
});


gulp.task("copy.resource.lib.dev", function(done) {
  return copyLibs("dev", done);
});

gulp.task("copy.resource.lib.prod", function(done) {
  return copyLibs("prod", done);
});

gulp.task("copy.resource.lib.static", function(done) {
  return copyLibs("static", done);
});

gulp.task("copy.resource.after.lib.dev", copyFuncWrap("dev"));
gulp.task("copy.resource.after.lib.prod", copyFuncWrap("prod"));
gulp.task("copy.resource.after.lib.static", copyFuncWrap("static"));

function copyFuncWrap(diff) {
  return function(done) {
    return gulp.src("src/reservation/Resources/resources.html")
      .pipe(rename({
        // dirname: "../",
        basename: diff === "static" ? "resources" : "CentralBooking",
        extname: appConfig.getViewExtension(diff)
      }))
      .pipe(changed(appConfig.getPath(diff)))
      .pipe(gulp.dest(appConfig.getPath(diff)))
      .pipe(inject(gulp.src([
        appConfig.getPath(diff, "./lib/fullcalendar/**/fullcalendar*.css"),
        appConfig.getPath(diff, "./lib/moment/moment.js"),
        appConfig.getPath(diff, "./lib/moment/*/moment*.js"),
        appConfig.getPath(diff, "./lib/jquery/dist/jquery*.js"),
        appConfig.getPath(diff, "./lib/fullcalendar/**/fullcalendar*.js"),
        appConfig.getPath(diff, "./lib/fullcalendar-resource/**/*"),
        appConfig.getPath(diff, "./css/commons*.css"),
        appConfig.getPath(diff, "./css/resources*.css"),
        appConfig.getPath(diff, "./js/common*.js"),
        appConfig.getPath(diff, "./js/resources*.js"),
      ], {read: false}), {
        relative: true,
        addPrefix: appConfig.getPrefixPath(diff),
        transform: function (filepath) {
          if (filepath.slice(-4) === '.css') {
            var isPrint = filepath.slice(-9) === 'print.css';
            var tag = [
              "<link href='",
              filepath,
              "'",
              " rel='stylesheet' ",
              isPrint ? "media='print'" : "",
              "/>"
            ].join("");

            return tag;
          }
          return inject.transform.apply(inject.transform, arguments);
        }
      }))
      .pipe(inject(gulp.src([
        ".app.json"
      ], {read: false}), {
        starttag: '<!-- inject:ide-path-def:{{ext}} -->',
        transform: function (filePath, file) {
          return appConfig.getIdePathDef(diff);
        }
      }))
      .pipe(inject(gulp.src([
        ".app.json"
      ], {read: false}), {
        starttag: '<!-- inject:ROOT_URL:{{ext}} -->',
        transform: function (filePath, file) {
          return appConfig.getROOT_URL(diff);
        }
      }))
      .pipe(gulp.dest(appConfig.getPath(diff)));
  }
}

/* script releated with fullcalendar */
function copyLibs(diff, done) {
  var libDirPath = "./node_modules/fullcalendar-resource/";
  var list = [
    diff === "prod" ? libDirPath + "./lib/moment/min/moment.min.js" : libDirPath + "./lib/moment/moment.js",
    diff === "prod" ? libDirPath + "./lib/jquery/dist/jquery.min.js" : libDirPath + "./lib/jquery/dist/jquery.js"
  ];
  if(diff === "prod"){
    list = list.concat([
      libDirPath + "./lib/fullcalendar/dist/fullcalendar.min.*",
      libDirPath + "./lib/fullcalendar/dist/fullcalendar.print.css",
      libDirPath + "./lib/fullcalendar-resource/js/fullcalendar.resource.min.js",
      libDirPath + "./lib/fullcalendar-resource/css/fullcalendar.resource.min.css"
    ]);
  }else{
    list = list.concat([
      libDirPath + "./lib/fullcalendar/*.js",
      libDirPath + "./lib/fullcalendar/*.css",
      libDirPath + "./lib/fullcalendar/*.map",
      libDirPath + "./lib/fullcalendar/src/**/*.*",
      libDirPath + "./lib/fullcalendar-resource/js/fullcalendar.resource.js",
      libDirPath + "./lib/fullcalendar-resource/css/fullcalendar.resource.css"
    ]);
  }
  return gulp.src(list, {base: libDirPath + "./lib"})
    .pipe(gulp.dest(appConfig.getPath(diff, "./lib")));
}
