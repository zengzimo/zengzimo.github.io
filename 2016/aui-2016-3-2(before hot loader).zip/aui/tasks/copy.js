"use strict";

var gulp = require("gulp");
var runSeq = require("run-sequence");

var tasksListDev = [];
var tasksListProd = [];
var tasksListStatic = [];

gulp.task("copy.dev", function(done) {
  _log(tasksListDev);
  return runSeq(tasksListDev, done);
});

gulp.task("copy.prod", function(done) {
  _log(tasksListProd);
  return runSeq(tasksListProd, done);
});

gulp.task("copy.static", function(done) {
  _log(tasksListStatic);
  return runSeq(tasksListStatic, done);
});

function register(name, diff) {
  if(!name) {
    console.error("[Gulp copy task]: Register module to copy queue need a name!");
    return;
  }
  if(!diff) {
    if(!hasTask(tasksListDev, name)) {
      tasksListDev.push(name);
    }
    if(!hasTask(tasksListProd, name)) {
      tasksListProd.push(name);
    }
    if(!hasTask(tasksListStatic, name)) {
      tasksListStatic.push(name);
    }
  }else {
    var tasksList;
    switch (diff) {
      case "dev":
        tasksList = tasksListDev;
        break;
      case "prod":
        tasksList = tasksListProd;
        break;
      default:
        tasksList = tasksListStatic;
    }

    if(!hasTask(tasksList, name)) {
      tasksList.push(name);
    }
  }
}

function hasTask(tasksList, name) {
  let tasks = tasksList.filter((tsk) => {
    return tsk === name ? true : false;
  })
  return tasks.length ? true : false;
}

function _log(taskList) {
  // let tasks = taskList || [];
  // tasks.forEach((tsk) => {
  //   console.log("[Gulp copy task]: Copy module '" + tsk + "' successfully!");
  // });
  // console.log("Total copied modules: " + tasks.length);
}

module.exports = {
  register: register
};
