"use strict";

var del = require("del");
var gulp = require("gulp");
var appConfig = require("./app.config");

var firstTime = true;

gulp.task("clean.dev", function(done) {
  return del([appConfig.getPath("dev")], {force: true});
});

gulp.task("clean.prod", function(done) {
  return del([appConfig.getPath("prod")], {force: true});
});

gulp.task("clean.static", function(done) {
  return del([appConfig.getPath("static")], done);
});
