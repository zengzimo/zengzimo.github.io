"use strict";

var fs = require('fs');
var path = require("path");

var config;
var appString = fs.readFileSync("./.app.json");
var defaultRootDir = "dist/";

try {
  config = JSON.parse(appString);
} catch (err) {
  console.error("==>     ERROR: Error parsing your .app.json");
  console.error(err);
}

function getPath(diff, joinPath) {
  var outputRootDir = config["output-dir-" + diff];
  if(!outputRootDir) {
    outputRootDir = defaultRootDir;
  }
  return path.join(outputRootDir, joinPath || "");
}

function getPrefixPath(diff, joinPath) {
  return diff === "static" ? "" : (config["ide-path-link"] || "");
}

function getIdePathDef(diff, joinPath) {
  return diff === "static" ? "" : (config["ide-path-def"] || "");
}

function getROOT_URL(diff, joinPath) {
  var ideRootPath = diff === "static" ? "" : (config["ide-path"] || "");
  return diff === "static" ? [
    "<script>",
      "var ROOT_URL = '';",
    "</script>"
  ].join("") : [
    "<script>",
      "var ROOT_URL = '", ideRootPath, "';",
    "</script>"
  ].join("");
}

function getViewExtension(diff, joinPath) {
  return diff === "static" ? ".html" : (config["output-view-ext"] || "");
}

module.exports = {
  config: config,
  getPath: getPath,
  getPrefixPath: getPrefixPath,
  getIdePathDef: getIdePathDef,
  getROOT_URL: getROOT_URL,
  getViewExtension: getViewExtension
};
