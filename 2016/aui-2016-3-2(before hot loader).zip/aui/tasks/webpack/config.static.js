"use strict";

var webpack = require("webpack");
var extend = require("extend");
var baseConfig = require("./config");
var appConfig = require("../app.config");
var ExtractTextPlugin = require("extract-text-webpack-plugin");

var config = {
  watch: true,
  devtool: "inline-source-map",
  output: {
    path: appConfig.getPath("static", "./js"),
    filename: "[name].js"
  },
  module: {
    loaders: [
      {
        test: /\.less$/,
        exclude: /node_modules(?![\/\\]react-aaui|[\/\\]font-awesome)/,
        loader: ExtractTextPlugin.extract("css?-minimize&sourceMap!autoprefixer?{browsers:['last 2 versions', 'ie 9']}!less?sourceMap")
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
        staticData: true
    }),
    new webpack.DefinePlugin({
        dev: true
    })
  ]
};

config.plugins = config.plugins.concat(baseConfig.plugins);
config.module.loaders = config.module.loaders.concat(baseConfig.module.loaders);

module.exports = extend({}, baseConfig, config);
