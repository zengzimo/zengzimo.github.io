"use strict";

var webpack = require("webpack");
var ExtractTextPlugin = require("extract-text-webpack-plugin");
var CommonsChunkPlugin = require("webpack/lib/optimize/CommonsChunkPlugin");

var config = {
  entry: {},
  output: {
    path: "dist/js",
    filename: "[name].js"
  },
  resolve: {
    extensions: ["", ".js", ".jsx"],
    modulesDirectories: ["src", "node_modules"]
  },
  module: {
    loaders: [
      {
        test: /\.(jsx|js)?$/,
        exclude: /node_modules(?![\/\\]react-aaui|[\/\\]func.js)/,
        loader: "babel",
        query: {
          plugins: ['transform-runtime'],
          presets: ["es2015", "stage-2", "react"],
          cacheDirectory: true
        }
      },
      {
        test: /\.(png|jpg|gif)$/,
        exclude: /node_modules(?![\/\\]react-aaui)/,
        loader: "file?name=../images/[name].[ext]"
      },
      {
        test: /\.(eot|ttf|svg|woff|woff2)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        exclude: /node_modules(?![\/\\]react-aaui|[\/\\]font-awesome)/,
        loader: "file?name=../fonts/[name].[ext]"
      }
    ]
  },
  plugins: [
    new webpack.ProvidePlugin({
      React: "react",
      flux: "aflux",
      PureRenderMixin: "react-addons-pure-render-mixin"
    }),
    new ExtractTextPlugin("../css/[name].css",
      {allChunks: true}
    ),
    new CommonsChunkPlugin({
      name: "commons",
      filename: "commons.js",
      minChunks: 3
    })
  ]
};

module.exports = config;
