"use strict";

var entryMapDev = {};
var entryMapProd = {};
var entryMapStatic = {};

function register(entry, diff) {
  if(!entry || !entry.name || !entry.value) {
    console.error("[Webpack build]: Unfit Entry format!");
    return;
  }

  if(!diff) {
    entryMapDev[entry.name] = entry.value;
    entryMapProd[entry.name] = entry.value;
    entryMapStatic[entry.name] = entry.value;
  }else {
    var entryMap;
    switch (diff) {
      case "dev":
        entryMap = entryMapDev;
        break;
      case "prod":
        entryMap = entryMapProd;
        break;
      default:
        entryMap = entryMapStatic;
    }
    entryMap[entry.name] = entry.value;
  }
}

module.exports = {
  dev: entryMapDev,
  prod: entryMapProd,
  static: entryMapStatic,
  register: register
};
